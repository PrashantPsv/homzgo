@extends('layouts.app')

@section('title', 'Cart & Booking')

@section('content')
@php
    $catalogUser = session('catalog_user');
    $catalogUser = is_array($catalogUser) ? ($catalogUser[0] ?? null) : $catalogUser;
@endphp

<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
@if(session('catalog_auth_token'))
<div
    x-data="cartCheckout({ initialCart: @js($cartItems ?? []), guestToken: @js($guestToken ?? null) })"
    x-init="init()"
    class="min-h-screen bg-gray-50"
>
    <div class="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">

        {{-- Page Header --}}
        <div class="mb-8">
            <h1 class="text-3xl font-bold text-gray-900">
                Your Cart
            </h1>

            <p class="mt-1 text-sm text-gray-500">
                Review your services and complete your booking.
            </p>
        </div>

        {{-- Empty Cart --}}
        <template x-if="!loading && cart.length === 0">
            <div class="rounded-2xl border border-gray-200 bg-white p-12 text-center shadow-sm">

                <div class="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-gray-100">
                    <svg
                        class="h-8 w-8 text-gray-400"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                    >
                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="1.8"
                            d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2 2h13m-9 4a1 1 0 100-2 1 1 0 000 2zm8 0a1 1 0 100-2 1 1 0 000 2z"
                        />
                    </svg>
                </div>

                <h2 class="mt-5 text-xl font-bold text-gray-900">
                    Your cart is empty
                </h2>

                <p class="mt-2 text-sm text-gray-500">
                    Add a service to continue.
                </p>

                <a
                    href="{{ url('/') }}"
                    class="mt-6 inline-flex rounded-xl bg-indigo-600 px-6 py-3 text-sm font-semibold text-white hover:bg-indigo-700"
                >
                    Browse Services
                </a>
            </div>
        </template>


        {{-- Main Checkout --}}
        <template x-if="!loading && cart.length > 0">
            <div class="grid gap-6 lg:grid-cols-3">

                {{-- LEFT --}}
                <div class="space-y-5 lg:col-span-2">


                    {{-- ================= SERVICES ================= --}}
                    <div class="rounded-2xl border border-gray-200 bg-white shadow-sm">

                        <div class="border-b border-gray-100 px-5 py-4">
                            <div class="flex items-center justify-between">

                                <div>
                                    <h2 class="font-bold text-gray-900">
                                        Selected Services
                                    </h2>

                                    <p class="mt-1 text-xs text-gray-500">
                                        <span x-text="cartCount"></span>
                                        item(s)
                                    </p>
                                </div>

                            </div>
                        </div>


                        <div class="divide-y divide-gray-100">

                            <template
                                x-for="item in cart"
                                :key="item.id"
                            >

                                <div class="p-5">

                                    <div class="flex gap-4">

                                        {{-- Image --}}
                                        <div class="h-24 w-24 shrink-0 overflow-hidden rounded-xl bg-gray-100">

                                            <template x-if="item.thumbnail_image">
                                                <img
                                                    :src="item.thumbnail_image"
                                                    :alt="item.name"
                                                    class="h-full w-full object-cover"
                                                >
                                            </template>

                                            <template x-if="!item.thumbnail_image">
                                                <div class="flex h-full items-center justify-center text-gray-400">

                                                    <svg
                                                        class="h-8 w-8"
                                                        fill="none"
                                                        stroke="currentColor"
                                                        viewBox="0 0 24 24"
                                                    >
                                                        <path
                                                            stroke-linecap="round"
                                                            stroke-linejoin="round"
                                                            stroke-width="1.8"
                                                            d="M5 3v18M19 3v18M5 8h14M5 16h14"
                                                        />
                                                    </svg>

                                                </div>
                                            </template>

                                        </div>


                                        {{-- Details --}}
                                        <div class="min-w-0 flex-1">

                                            <div class="flex items-start justify-between gap-4">

                                                <div>
                                                    <h3
                                                        class="font-semibold text-gray-900"
                                                        x-text="item.name"
                                                    ></h3>

                                                    <p class="mt-1 text-sm text-gray-500">
                                                        ₹<span
                                                            x-text="Number(item.price).toFixed(2)"
                                                        ></span>
                                                        per item
                                                    </p>
                                                </div>

                                                <p class="font-bold text-gray-900">
                                                    ₹<span
                                                        x-text="(
                                                            Number(item.price) *
                                                            Number(item.quantity)
                                                        ).toFixed(2)"
                                                    ></span>
                                                </p>

                                            </div>


                                            {{-- Quantity --}}
                                            <div class="mt-4 flex items-center">

                                                <div class="flex items-center overflow-hidden rounded-lg border border-gray-200">

                                                    <button
                                                        type="button"
                                                        @click="decrease(item)"
                                                        :disabled="item.loading"
                                                        class="flex h-9 w-9 items-center justify-center text-lg font-bold text-gray-600 hover:bg-gray-50 disabled:opacity-50"
                                                    >
                                                        −
                                                    </button>

                                                    <span
                                                        class="flex h-9 min-w-[40px] items-center justify-center text-sm font-semibold"
                                                        x-text="item.quantity"
                                                    ></span>

                                                    <button
                                                        type="button"
                                                        @click="increase(item)"
                                                        :disabled="item.loading"
                                                        class="flex h-9 w-9 items-center justify-center text-lg font-bold text-gray-600 hover:bg-gray-50 disabled:opacity-50"
                                                    >
                                                        +
                                                    </button>

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                </div>

                            </template>

                        </div>

                    </div>

                    {{-- Address List --}}
                    <div
                        x-show="!addressLoading && !addressError"
                        x-cloak
                        class="rounded-xl border border-gray-200 bg-white p-4"
                    >
                        <template x-if="addresses.length > 0">

                            <div class="space-y-3">

                                <template
                                    x-for="item in addresses"
                                    :key="item.id"
                                >

                                    <button
                                        type="button"
                                        @click="selectAddress(item)"
                                        class="w-full rounded-xl border p-4 text-left transition"
                                        :class="
                                            Number(address?.id) === Number(item.id)
                                                ? 'border-indigo-600 bg-indigo-50 ring-1 ring-indigo-600'
                                                : 'border-gray-200 hover:border-indigo-300'
                                        "
                                    >

                                        <div class="flex items-start gap-3">

                                            {{-- Icon --}}
                                            <div
                                                class="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg"
                                                :class="
                                                    Number(address?.id) === Number(item.id)
                                                        ? 'bg-indigo-600 text-white'
                                                        : 'bg-gray-100 text-gray-500'
                                                "
                                            >

                                                <template
                                                    x-if="String(item.type).toLowerCase() === 'home'"
                                                >
                                                    <svg
                                                        class="h-5 w-5"
                                                        fill="none"
                                                        stroke="currentColor"
                                                        viewBox="0 0 24 24"
                                                    >
                                                        <path
                                                            stroke-linecap="round"
                                                            stroke-linejoin="round"
                                                            stroke-width="1.8"
                                                            d="M3 10.5L12 3l9 7.5M5 9v11h14V9M9 20v-6h6v6"
                                                        />
                                                    </svg>
                                                </template>

                                                <template
                                                    x-if="String(item.type).toLowerCase() !== 'home'"
                                                >
                                                    <svg
                                                        class="h-5 w-5"
                                                        fill="none"
                                                        stroke="currentColor"
                                                        viewBox="0 0 24 24"
                                                    >
                                                        <path
                                                            stroke-linecap="round"
                                                            stroke-linejoin="round"
                                                            stroke-width="1.8"
                                                            d="M4 21V5a2 2 0 012-2h12a2 2 0 012 2v16M4 21h16M8 7h2m4 0h2M8 11h2m4 0h2M8 15h2m4 0h2"
                                                        />
                                                    </svg>
                                                </template>

                                            </div>

                                            {{-- Address --}}
                                            <div class="min-w-0 flex-1">

                                                <div class="flex flex-wrap items-center gap-2">

                                                    <span
                                                        class="font-semibold capitalize text-gray-900"
                                                        x-text="item.type || 'Address'"
                                                    ></span>

                                                    <span
                                                        x-show="item.is_default === true || Number(item.is_default) === 1"
                                                        class="rounded-full bg-green-100 px-2 py-0.5 text-xs font-semibold text-green-700"
                                                    >
                                                        Default
                                                    </span>

                                                    <span
                                                        x-show="Number(address?.id) === Number(item.id)"
                                                        class="rounded-full bg-indigo-100 px-2 py-0.5 text-xs font-semibold text-indigo-700"
                                                    >
                                                        Selected
                                                    </span>

                                                </div>

                                                {{-- Main address --}}
                                                <p
                                                    class="mt-2 text-sm leading-5 text-gray-700"
                                                    x-text="item.address"
                                                ></p>

                                                {{-- Landmark --}}
                                                <p
                                                    x-show="item.landmark"
                                                    class="mt-1 text-xs text-gray-500"
                                                >
                                                    Landmark:
                                                    <span x-text="item.landmark"></span>
                                                </p>

                                                {{-- Floor --}}
                                                <p
                                                    x-show="item.floor"
                                                    class="mt-1 text-xs text-gray-500"
                                                >
                                                    Floor:
                                                    <span x-text="item.floor"></span>
                                                </p>

                                                {{-- Instructions --}}
                                                <p
                                                    x-show="item.instructions"
                                                    class="mt-1 text-xs text-gray-500"
                                                >
                                                    Instructions:
                                                    <span x-text="item.instructions"></span>
                                                </p>

                                            </div>

                                        </div>

                                    </button>

                                </template>

                            </div>

                        </template>

                        {{-- No Address --}}
                        <template x-if="addresses.length === 0">

                            <div class="rounded-xl border border-dashed border-gray-300 p-8 text-center">

                                <div class="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-gray-100">

                                    <svg
                                        class="h-6 w-6 text-gray-400"
                                        fill="none"
                                        stroke="currentColor"
                                        viewBox="0 0 24 24"
                                    >
                                        <path
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                            stroke-width="1.8"
                                            d="M12 21s8-4.5 8-10a8 8 0 10-16 0c0 5.5 8 10 8 10z"
                                        />

                                        <circle
                                            cx="12"
                                            cy="11"
                                            r="2.5"
                                            stroke-width="1.8"
                                        />
                                    </svg>

                                </div>

                                <h3 class="mt-3 font-semibold text-gray-900">
                                    No saved addresses
                                </h3>

                                <p class="mt-1 text-sm text-gray-500">
                                    Add an address to continue with your booking.
                                </p>

                            </div>

                        </template>

                        {{-- Add Address --}}
                        <template x-if="!addressError">
                            <button
                                type="button"
                                @click="openAddAddress()"
                                class="mt-4 block w-full rounded-xl border border-dashed border-indigo-300 p-3 text-center text-sm font-semibold text-indigo-600 transition hover:bg-indigo-50"
                            >
                                + Add New Address
                            </button>
                        </template>

                        {{-- Login --}}
                        <template x-if="addressError === 'Please login to continue.'">
                            <a
                                href="{{ route('login') }}"
                                class="mt-4 block rounded-xl border border-dashed border-indigo-300 p-3 text-center text-sm font-semibold text-indigo-600 transition hover:bg-indigo-50"
                            >
                                + Please login to select or add a service address.
                            </a>
                        </template>

                    </div>

                    {{-- ================= DATE & TIME ================= --}}
                    <div class="rounded-2xl border border-gray-200 bg-white shadow-sm">

                        <div class="border-b border-gray-100 px-5 py-4">

                            <div class="flex items-center gap-3">

                                <div
                                    class="flex h-9 w-9 items-center justify-center rounded-full"
                                    :class="
                                        date && time
                                            ? 'bg-green-100 text-green-600'
                                            : 'bg-indigo-100 text-indigo-600'
                                    "
                                >
                                    <span
                                        x-show="date && time"
                                        class="font-bold"
                                    >
                                        ✓
                                    </span>

                                    <span
                                        x-show="!date || !time"
                                        class="font-bold"
                                    >
                                        2
                                    </span>
                                </div>

                                <div>

                                    <h2 class="font-bold text-gray-900">
                                        Date & Time
                                    </h2>

                                    <p
                                        x-show="date && time"
                                        class="text-xs text-gray-500"
                                        x-text="formattedDate + ' · ' + time"
                                    ></p>

                                    <p
                                        x-show="!date || !time"
                                        class="text-xs text-gray-500"
                                    >
                                        Choose your preferred service time
                                    </p>

                                </div>

                            </div>

                        </div>


                        <div class="p-5">

                            {{-- Dates --}}
                            <h3 class="text-sm font-semibold text-gray-900">
                                Select Date
                            </h3>

                            <div class="mt-3 grid grid-cols-3 gap-3 sm:grid-cols-5">

                                <template
                                    x-for="day in availableDates"
                                    :key="day.value"
                                >

                                    <button
                                        type="button"
                                        @click="selectDate(day.value)"
                                        class="rounded-xl border px-3 py-3 text-center transition"
                                        :class="
                                            date === day.value
                                                ? 'border-indigo-600 bg-indigo-600 text-white'
                                                : 'border-gray-200 hover:border-indigo-300'
                                        "
                                    >

                                        <span
                                            class="block text-xs"
                                            x-text="day.day"
                                        ></span>

                                        <span
                                            class="mt-1 block text-lg font-bold"
                                            x-text="day.number"
                                        ></span>

                                        <span
                                            class="block text-xs"
                                            x-text="day.month"
                                        ></span>

                                    </button>

                                </template>

                            </div>


                            {{-- Time --}}
                            <h3 class="mt-6 text-sm font-semibold text-gray-900">
                                Select Time
                            </h3>

                            <div class="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-4">

                                <template
                                    x-for="slot in timeSlots"
                                    :key="slot"
                                >

                                    <button
                                        type="button"
                                        @click="time = slot"
                                        class="rounded-xl border px-4 py-3 text-sm font-medium transition"
                                        :class="
                                            time === slot
                                                ? 'border-indigo-600 bg-indigo-600 text-white'
                                                : 'border-gray-200 text-gray-700 hover:border-indigo-300'
                                        "
                                        x-text="slot"
                                    ></button>

                                </template>

                            </div>

                        </div>

                    </div>


                    {{-- ================= CUSTOMER DETAILS ================= --}}
                    <div class="rounded-2xl border border-gray-200 bg-white shadow-sm">

                        <div class="border-b border-gray-100 px-5 py-4">

                            <div class="flex items-center gap-3">

                                <div
                                    class="flex h-9 w-9 items-center justify-center rounded-full"
                                    :class="
                                        customer.name && customer.phone
                                            ? 'bg-green-100 text-green-600'
                                            : 'bg-indigo-100 text-indigo-600'
                                    "
                                >

                                    <span
                                        x-show="customer.name && customer.phone"
                                        class="font-bold"
                                    >
                                        ✓
                                    </span>

                                    <span
                                        x-show="!customer.name || !customer.phone"
                                        class="font-bold"
                                    >
                                        3
                                    </span>

                                </div>

                                <div>

                                    <h2 class="font-bold text-gray-900">
                                        Customer Details
                                    </h2>

                                    <p class="text-xs text-gray-500">
                                        Enter your contact details
                                    </p>

                                </div>

                            </div>

                        </div>


                        <div class="p-5">

                            <div class="grid gap-5 sm:grid-cols-2">

                                {{-- Name --}}
                                <div>

                                    <label class="text-sm font-semibold text-gray-700">
                                        Full Name
                                    </label>

                                    <input
                                        type="text"
                                        x-model="customer.name"
                                        placeholder="Enter your name"
                                        class="mt-2 w-full rounded-xl border border-gray-200 px-4 py-3 text-sm outline-none transition focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100"
                                    >

                                </div>


                                {{-- Phone --}}
                                <div>

                                    <label class="text-sm font-semibold text-gray-700">
                                        Phone Number
                                    </label>

                                    <input
                                        type="tel"
                                        x-model="customer.phone"
                                        placeholder="Enter phone number"
                                        class="mt-2 w-full rounded-xl border border-gray-200 px-4 py-3 text-sm outline-none transition focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100"
                                    >

                                </div>


                                {{-- Email --}}
                                <div class="sm:col-span-2">

                                    <label class="text-sm font-semibold text-gray-700">
                                        Email Address
                                    </label>

                                    <input
                                        type="email"
                                        x-model="customer.email"
                                        placeholder="Enter email address"
                                        class="mt-2 w-full rounded-xl border border-gray-200 px-4 py-3 text-sm outline-none transition focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100"
                                    >

                                </div>

                            </div>

                        </div>

                    </div>

                </div>


                {{-- ================= RIGHT SUMMARY ================= --}}
                <div>

                    <div class="sticky top-24 rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">

                        <h2 class="text-lg font-bold text-gray-900">
                            Order Summary
                        </h2>


                        {{-- Items --}}
                        <div class="mt-5 space-y-4">

                            <template
                                x-for="item in cart"
                                :key="item.id"
                            >

                                <div class="flex justify-between gap-4 text-sm">

                                    <div class="min-w-0">

                                        <p
                                            class="font-medium text-gray-900"
                                            x-text="item.name"
                                        ></p>

                                        <p class="mt-1 text-gray-500">
                                            Qty:
                                            <span x-text="item.quantity"></span>
                                        </p>

                                    </div>

                                    <span class="shrink-0 font-medium text-gray-900">
                                        ₹<span
                                            x-text="(
                                                Number(item.price) *
                                                Number(item.quantity)
                                            ).toFixed(2)"
                                        ></span>
                                    </span>

                                </div>

                            </template>

                        </div>


                        <div class="my-5 border-t"></div>


                        {{-- Address Summary --}}
                        <div x-show="address">

                            <p class="text-xs font-semibold uppercase tracking-wide text-gray-400">
                                Service Address
                            </p>

                            <p
                                class="mt-2 text-sm font-semibold text-gray-900"
                                x-text="address?.type"
                            ></p>

                            <p
                                class="mt-1 text-sm leading-5 text-gray-500"
                                x-text="address?.address + ', ' + address?.area"
                            ></p>

                        </div>


                        {{-- Date Summary --}}
                        <div
                            x-show="date && time"
                            class="mt-5"
                        >

                            <p class="text-xs font-semibold uppercase tracking-wide text-gray-400">
                                Service Time
                            </p>

                            <p
                                class="mt-2 text-sm font-semibold text-gray-900"
                                x-text="formattedDate"
                            ></p>

                            <p
                                class="mt-1 text-sm text-gray-500"
                                x-text="time"
                            ></p>

                        </div>


                        <div class="my-5 border-t"></div>


                        {{-- Total --}}
                        <div class="flex items-center justify-between">

                            <span class="font-bold text-gray-900">
                                Total
                            </span>

                            <span class="text-xl font-bold text-gray-900">
                                ₹<span x-text="cartTotal.toFixed(2)"></span>
                            </span>

                        </div>


                        {{-- Validation --}}
                        <div
                            x-show="!isCheckoutComplete"
                            class="mt-4 rounded-xl bg-amber-50 p-3 text-xs leading-5 text-amber-700"
                        >
                            Please complete:

                            <ul class="mt-1 list-inside list-disc">

                                <li x-show="!address">
                                    Service address
                                </li>

                                <li x-show="!date || !time">
                                    Date & time
                                </li>

                                <li x-show="!customer.name || !customer.phone">
                                    Customer details
                                </li>

                            </ul>
                        </div>


                        {{-- Payment Button --}}
                        <button
                            type="button"
                            @click="proceedToPayment()"
                            :disabled="paymentLoading"
                            class="w-full rounded-xl bg-black px-5 py-3 text-sm font-semibold text-white transition hover:bg-gray-800 disabled:cursor-not-allowed disabled:opacity-50"
                        >
                            <template x-if="!paymentLoading">
                                <span>
                                    Proceed to Payment
                                </span>
                            </template>

                            <template x-if="paymentLoading">
                                <span class="flex items-center justify-center gap-2">
                                    <svg
                                        class="h-5 w-5 animate-spin"
                                        viewBox="0 0 24 24"
                                        fill="none"
                                    >
                                        <circle
                                            cx="12"
                                            cy="12"
                                            r="10"
                                            stroke="currentColor"
                                            stroke-width="4"
                                            class="opacity-25"
                                        ></circle>

                                        <path
                                            d="M4 12a8 8 0 018-8"
                                            stroke="currentColor"
                                            stroke-width="4"
                                        ></path>
                                    </svg>

                                    Processing...
                                </span>
                            </template>
                        </button>

                    </div>

                </div>

            </div>
        </template>

    </div>
</div>

<div
    x-show="addressModalOpen"
    x-cloak
    class="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
>
    <div
        @click.outside="addressModalOpen = false"
        class="w-full max-w-lg rounded-2xl bg-white p-6 shadow-xl"
    >

        <div class="flex items-center justify-between">
            <h2 class="text-lg font-bold text-gray-900">
                Add New Address
            </h2>

            <button
                type="button"
                @click="addressModalOpen = false"
                class="text-gray-400 hover:text-gray-700"
            >
                ✕
            </button>
        </div>

        {{-- Your address form here --}}

    </div>
</div>
@else
<div
    x-data="cartCheckout({ initialCart: @js($cartItems ?? []), guestToken: @js($guestToken ?? null) })"
    x-init="init()"
    class="min-h-screen bg-gray-50"
>
    <div class="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">

        {{-- Page Header --}}
        <div class="mb-8">
            <h1 class="text-3xl font-bold text-gray-900">
                Your Cart
            </h1>
            <p>
                To book the service, please login or sign up
            </p>
            <button
                onclick="window.dispatchEvent(new CustomEvent('open-login'))"
                class="mt-4 block rounded-xl border border-dashed border-indigo-300 p-3 text-center text-sm font-semibold text-indigo-600 transition hover:bg-indigo-50"
            >
                Login
            </button>
        </div>
    </div>
</div>
@endif

@endsection


@push('scripts')
<script>
function cartCheckout(config = {}) {
    return {

        loading: true,

        cart: (config.initialCart || []).map(item => ({...item})),

        guestToken: config.guestToken || null,

        // =========================
        // ADDRESS
        // =========================

        address: null,

        addresses: [],
        addressLoading: false,
        addressError: null,


        // =========================
        // DATE / TIME
        // =========================

        date: '',
        time: '',

        availableDates: [],

        timeSlots: [
            '09:00 AM',
            '10:00 AM',
            '11:00 AM',
            '12:00 PM',
            '01:00 PM',
            '02:00 PM',
            '03:00 PM',
            '04:00 PM',
            '05:00 PM',
            '06:00 PM',
        ],


        // =========================
        // CUSTOMER
        // =========================

        customer: {
            name: '',
            phone: '',
            email: '',
        },


        addressModalOpen: false,

        addressForm: {
            type: 'home',
            address: '',
            latitude: '',
            longitude: '',
            landmark: '',
            floor: '',
            instructions: '',
            is_default: false,
        },

        paymentLoading: false,

        // =========================
        // INIT
        // =========================

        init() {

            this.loadGuestToken();

            this.loadSavedBookingData();

            this.generateDates();

            this.loadAddresses();

            this.loading = false;
        },


        // =========================
        // CART
        // =========================

        loadCart() {

            try {

                const savedCart =
                    localStorage.getItem('servicehub_cart');

                this.cart = savedCart
                    ? JSON.parse(savedCart)
                    : [];

            } catch (error) {

                console.error(
                    'Cart load error:',
                    error
                );

                this.cart = [];
            }
        },

        openAddAddress() {
            this.addressModalOpen = true;

            // Reset form if required
            this.addressForm = {
                type: 'home',
                address: '',
                latitude: '',
                longitude: '',
                landmark: '',
                floor: '',
                instructions: '',
                is_default: false,
            };
        },

        async proceedToPayment() {
            
            if (this.paymentLoading) {
                return;
            }

            /*
             * Basic validation
             */

            if (!this.customer.name) {
                alert('Please enter your name.');
                return;
            }

            if (!this.customer.phone) {
                alert('Please enter your phone number.');
                return;
            }

            if (!this.address) {
                alert('Please select a service address.');
                return;
            }

            if (!this.date) {
                alert('Please select a service date.');
                return;
            }

            if (!this.time) {
                alert('Please select a service time.');
                return;
            }


            /*
             * Check cart
             */

            if (!this.cartTotal || Number(this.cartTotal) <= 0) {

                alert('Your cart is empty.');

                return;
            }


            this.paymentLoading = true;


            try {

                /*
                 * Create Razorpay Order
                 */

                const response = await fetch(
                    "{{ route('payment.create') }}",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type": "application/json",

                            "Accept": "application/json",

                            "X-CSRF-TOKEN":
                                document
                                    .querySelector(
                                        'meta[name="csrf-token"]'
                                    )
                                    .getAttribute('content')
                        },

                        body: JSON.stringify({

                            /*
                             * Temporary.
                             *
                             * Ideally Laravel should calculate
                             * this from the cart.
                             */
                            amount: Number(this.cartTotal)

                        })
                    }
                );


                const data = await response.json();


                if (!response.ok || !data.success) {

                    throw new Error(
                        data.message ||
                        'Unable to create payment order.'
                    );
                }


                /*
                 * Razorpay Checkout Options
                 */

                const options = {

                    key: data.key,

                    amount: data.amount,

                    currency: data.currency,

                    name: "ServiceHub",

                    description: "Service Booking",

                    order_id: data.order_id,


                    /*
                     * Customer information
                     */

                    prefill: {

                        name:
                            this.customer.name || '',

                        email:
                            this.customer.email || '',

                        contact:
                            this.customer.phone || ''

                    },


                    /*
                     * Payment success
                     */

                    handler: async (paymentResponse) => {

                        console.log(
                            'Razorpay Payment Response:',
                            paymentResponse
                        );

                        await this.verifyPayment(
                            paymentResponse
                        );
                    },


                    /*
                     * Checkout closed
                     */

                    modal: {

                        ondismiss: () => {

                            console.log(
                                'Razorpay checkout closed'
                            );

                            this.paymentLoading = false;

                        }

                    },


                    /*
                     * Theme
                     */

                    theme: {

                        color: "#111827"

                    }

                };


                /*
                 * Create Razorpay instance
                 */

                const razorpay = new Razorpay(options);


                /*
                 * Payment failed
                 */

                razorpay.on(
                    'payment.failed',
                    (response) => {

                        console.error(
                            'Razorpay Payment Failed:',
                            response.error
                        );


                        this.paymentLoading = false;


                        alert(
                            response.error.description ||
                            'Payment failed. Please try again.'
                        );

                    }
                );


                /*
                 * Open Razorpay
                 */

                razorpay.open();


            } catch (error) {

                console.error(
                    'Payment Error:',
                    error
                );


                alert(
                    error.message ||
                    'Unable to start payment.'
                );


                this.paymentLoading = false;
            }
        },


        /**
         * Verify payment with Laravel
         */

        async verifyPayment(paymentResponse) {
            try {

                const response = await fetch(
                    "{{ route('payment.verify') }}",
                    {
                        method: "POST",

                        headers: {

                            "Content-Type":
                                "application/json",

                            "Accept":
                                "application/json",

                            "X-CSRF-TOKEN":
                                document
                                    .querySelector(
                                        'meta[name="csrf-token"]'
                                    )
                                    .getAttribute('content')

                        },

                        body: JSON.stringify({

                            razorpay_order_id:
                                paymentResponse.razorpay_order_id,

                            razorpay_payment_id:
                                paymentResponse.razorpay_payment_id,

                            razorpay_signature:
                                paymentResponse.razorpay_signature,

                            address_id:this.address.id,

                            slots: Object.fromEntries(this.cart.map(item => [
                                String(item.id || item.package_id),
                                { slot_date: this.date, slot_time: convertTo24Hour(this.time) }
                            ]))

                        })
                    }
                );


                const data =
                    await response.json();


                if (
                    !response.ok ||
                    !data.success
                ) {

                    throw new Error(
                        data.message ||
                        'Payment verification failed.'
                    );

                }


                /*
                 * Payment successfully verified
                 */

                console.log(
                    'Payment Verified Successfully'
                );


                /*
                 * Redirect
                 */

                window.location.href =
                    data.redirect;


            } catch (error) {

                console.error(
                    'Payment Verification Error:',
                    error
                );


                alert(
                    error.message ||
                    'Payment verification failed.'
                );


                this.paymentLoading = false;
            }
        },
        async loadAddresses() {
            this.addressLoading = true;
            this.addressError = null;

            try {
                const response = await fetch(
                    '{{ route('cart.addresses') }}',
                    {
                        method: 'GET',
                        headers: {
                            'Accept': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest',
                        },
                        credentials: 'same-origin',
                    }
                );

                const result = await response.json();

                console.log('ADDRESS API RESPONSE:', result);

                /*
                 * User is not logged in
                 */
                if (
                    response.status === 401 ||
                    result.message === 'Please login to continue.'
                ) {
                    this.addresses = [];
                    this.address = null;
                    this.addressError = 'Please login to continue.';

                    return;
                }

                /*
                 * API returned an error
                 */
                if (!response.ok || !result.status) {
                    throw new Error(
                        result.message || 'Unable to load addresses.'
                    );
                }

                /*
                 * API response:
                 *
                 * {
                 *     status: true,
                 *     message: "Success",
                 *     data: [...]
                 * }
                 */
                this.addresses = Array.isArray(result.data)
                    ? result.data
                    : [];

                this.address = null;

                /*
                 * Find default address
                 */
                const defaultAddress = this.addresses.find(
                    item =>
                        item.is_default === true ||
                        Number(item.is_default) === 1
                );

                /*
                 * Select default address
                 */
                if (defaultAddress) {
                    this.selectAddress(defaultAddress);
                }
                /*
                 * If there is only one address, select it
                 */
                else if (this.addresses.length === 1) {
                    this.selectAddress(this.addresses[0]);
                }

                console.log('ADDRESSES:', this.addresses);
                console.log('SELECTED ADDRESS:', this.address);

            } catch (error) {
                console.error('Address loading error:', error);

                this.addresses = [];
                this.address = null;

                this.addressError =
                    error.message ||
                    'Unable to load addresses.';

            } finally {
                this.addressLoading = false;
            }
        },

        loadGuestToken() {
            if (!this.guestToken) {
                this.guestToken = localStorage.getItem('servicehub_guest_token');
            }
            if (this.guestToken) {
                localStorage.setItem('servicehub_guest_token', this.guestToken);
            }
        },


        saveCart() {

            localStorage.setItem(
                'servicehub_cart',
                JSON.stringify(this.cart)
            );
        },


        // =========================
        // CART QUANTITY
        // =========================

        async increase(item) {

            const quantity =
                Number(item.quantity) + 1;

            await this.updateCartQuantity(
                item,
                quantity
            );
        },


        async decrease(item) {

            const quantity =
                Number(item.quantity);

            if (quantity <= 1) {

                await this.removeCartItem(item);

                return;
            }

            await this.updateCartQuantity(
                item,
                quantity - 1
            );
        },


        async updateCartQuantity(
            item,
            quantity
        ) {

            item.loading = true;

            try {

                const response = await fetch(
                    `/cart/items/${item.cart_item_id || item.id}`,
                    {
                        method: 'PUT',

                        headers: {
                            'Content-Type':
                                'application/json',

                            'Accept':
                                'application/json',

                            'X-Requested-With':
                                'XMLHttpRequest',

                            'X-CSRF-TOKEN':
                                document
                                    .querySelector(
                                        'meta[name="csrf-token"]'
                                    )
                                    ?.getAttribute(
                                        'content'
                                    ) || '',
                        },

                        credentials: 'same-origin',

                        body: JSON.stringify({
                            quantity: Number(quantity),
                            guest_token: this.guestToken,
                            slot_date: this.date || undefined,
                            slot_time: this.time ? convertTo24Hour(this.time) : undefined,
                        }),
                    }
                );


                const result =
                    await response.json();


                if (
                    !response.ok ||
                    !result.status
                ) {

                    throw new Error(
                        result.message ||
                        'Unable to update cart.'
                    );
                }


                item.quantity =
                    Number(quantity);

                this.saveCart();

            } catch (error) {

                console.error(
                    'Cart update error:',
                    error
                );

                alert(
                    error.message ||
                    'Unable to update cart.'
                );

            } finally {

                item.loading = false;
            }
        },


        // =========================
        // DELETE CART ITEM
        // =========================

        async removeCartItem(item) {

            if (!item.cart_item_id) {

                console.error(
                    'Cart item ID missing:',
                    item
                );

                alert(
                    'Cart item ID is missing.'
                );

                return;
            }


            item.loading = true;


            try {

                const response = await fetch(
                    `/cart/items/${item.cart_item_id}`,
                    {
                        method: 'DELETE',

                        headers: {
                            'Content-Type':
                                'application/json',

                            'Accept':
                                'application/json',

                            'X-Requested-With':
                                'XMLHttpRequest',

                            'X-CSRF-TOKEN':
                                document
                                    .querySelector(
                                        'meta[name="csrf-token"]'
                                    )
                                    ?.getAttribute(
                                        'content'
                                    ) || '',
                        },

                        credentials: 'same-origin',

                        body: JSON.stringify({
                            guest_token:
                                this.guestToken,
                        }),
                    }
                );


                const result =
                    await response.json();


                if (
                    !response.ok ||
                    !result.status
                ) {

                    throw new Error(
                        result.message ||
                        'Unable to remove item.'
                    );
                }


                this.cart =
                    this.cart.filter(
                        cartItem =>
                            Number(cartItem.id) !==
                            Number(item.id)
                    );


                this.saveCart();

            } catch (error) {

                console.error(
                    'Remove cart item error:',
                    error
                );

                alert(
                    error.message ||
                    'Unable to remove item.'
                );

            } finally {

                item.loading = false;
            }
        },


        // =========================
        // ADDRESS
        // =========================

        selectAddress(address) {

            this.address =
                address;


            localStorage.setItem(
                'servicehub_booking_address',
                JSON.stringify(address)
            );
        },


        // =========================
        // DATE
        // =========================

        async selectDate(value) {
            this.date = value;
            this.time = '';
            try {
                const response = await fetch(`{{ route('booking.slots') }}?date=${encodeURIComponent(value)}`, { headers: { 'Accept': 'application/json' }, credentials: 'same-origin' });
                const result = await response.json();
                if (!response.ok || !result.status) throw new Error(result.message || 'Unable to load time slots.');
                const raw = result.data?.slots ?? result.data ?? [];
                this.timeSlots = Array.isArray(raw) ? raw.map(s => typeof s === 'string' ? s : (s.time || s.label || s.start_time)).filter(Boolean) : Object.values(raw).flat().map(s => typeof s === 'string' ? s : (s.time || s.label || s.start_time)).filter(Boolean);
            } catch (error) {
                console.error('Slot loading error:', error);
                this.timeSlots = [];
            }
        },

        generateDates() {

            const today =
                new Date();


            for (
                let i = 0;
                i < 7;
                i++
            ) {

                const date =
                    new Date(today);


                date.setDate(
                    today.getDate() + i
                );


                this.availableDates.push({

                    value:
                        this.formatDate(date),

                    day:
                        date.toLocaleDateString(
                            'en-US',
                            {
                                weekday: 'short'
                            }
                        ),

                    number:
                        date.getDate(),

                    month:
                        date.toLocaleDateString(
                            'en-US',
                            {
                                month: 'short'
                            }
                        ),
                });
            }
        },


        formatDate(date) {

            return date
                .toISOString()
                .split('T')[0];
        },


        // =========================
        // SAVED DATA
        // =========================

        loadSavedBookingData() {

            try {

                const savedAddress =
                    localStorage.getItem(
                        'servicehub_booking_address'
                    );

                if (savedAddress) {

                    this.address =
                        JSON.parse(
                            savedAddress
                        );
                }


                const savedDateTime =
                    localStorage.getItem(
                        'servicehub_booking_datetime'
                    );

                if (savedDateTime) {

                    const data =
                        JSON.parse(
                            savedDateTime
                        );

                    this.date =
                        data.date || '';

                    this.time =
                        data.time || '';
                }


                const savedCustomer =  @json($catalogUser);
                console.log(savedCustomer)
                if (savedCustomer) {

                    this.customer.name = savedCustomer.name
                    this.customer.phone = savedCustomer.phone_number || savedCustomer.phone || savedCustomer.mobile || ''
                    this.customer.email = savedCustomer.email
                }

            } catch (error) {

                console.error(
                    'Saved booking data error:',
                    error
                );
            }
        },


        // =========================
        // SAVE CHECKOUT DATA
        // =========================

        saveCheckoutData() {

            localStorage.setItem(
                'servicehub_booking_datetime',
                JSON.stringify({
                    date: this.date,
                    time: this.time,
                })
            );


            localStorage.setItem(
                'servicehub_customer',
                JSON.stringify(
                    this.customer
                )
            );


            if (this.address) {

                localStorage.setItem(
                    'servicehub_booking_address',
                    JSON.stringify(
                        this.address
                    )
                );
            }
        },

        // =========================
        // COMPUTED
        // =========================

        get cartCount() {

            return this.cart.reduce(
                (
                    total,
                    item
                ) =>
                    total +
                    Number(
                        item.quantity
                    ),
                0
            );
        },


        get cartTotal() {

            return this.cart.reduce(
                (
                    total,
                    item
                ) =>
                    total +
                    (
                        Number(
                            item.price
                        ) *
                        Number(
                            item.quantity
                        )
                    ),
                0
            );
        },


        get formattedDate() {

            if (!this.date) {
                return '';
            }


            const date =
                new Date(
                    this.date +
                    'T00:00:00'
                );


            return date.toLocaleDateString(
                'en-US',
                {
                    weekday: 'short',
                    day: 'numeric',
                    month: 'short',
                }
            );
        },


        get isCheckoutComplete() {

            return (
                this.cart.length > 0 &&
                !!this.address &&
                !!this.date &&
                !!this.time &&
                !!this.customer.name &&
                !!this.customer.phone
            );
        },
    };
}
function convertTo24Hour(time) {
    const [timePart, modifier] = time.trim().split(/\s+/);

    let [hours, minutes] = timePart.split(':').map(Number);

    if (modifier.toUpperCase() === 'PM' && hours !== 12) {
        hours += 12;
    }

    if (modifier.toUpperCase() === 'AM' && hours === 12) {
        hours = 0;
    }

    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
}
</script>
@endpush