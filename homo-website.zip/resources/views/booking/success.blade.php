@extends('layouts.app')

@section('title', 'Booking Confirmed | ServiceHub')

@section('content')

<div class="min-h-screen bg-gray-50">

    {{-- Success Hero --}}
    <section class="border-b border-gray-200 bg-white">
        <div class="mx-auto max-w-4xl px-4 py-12 text-center sm:px-6 lg:px-8">

            {{-- Success Icon --}}
            <div class="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-green-100">
                <div class="flex h-14 w-14 items-center justify-center rounded-full bg-green-500 text-white">
                    <svg
                        class="h-8 w-8"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                    >
                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="2"
                            d="M5 13l4 4L19 7"
                        />
                    </svg>
                </div>
            </div>

            <p class="mt-6 text-sm font-semibold uppercase tracking-wider text-green-600">
                Booking Confirmed
            </p>

            <h1 class="mt-2 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
                Your service is booked!
            </h1>

            <p class="mx-auto mt-3 max-w-2xl text-sm leading-6 text-gray-500 sm:text-base">
                Thank you for choosing ServiceHub. Your booking has been confirmed successfully.
                We'll keep you updated about your service.
            </p>

            {{-- Booking Number --}}
            <div class="mx-auto mt-6 inline-flex items-center gap-3 rounded-xl border border-gray-200 bg-gray-50 px-5 py-3">

                <span class="text-sm text-gray-500">
                    Booking ID
                </span>

                <span class="font-mono text-sm font-bold text-gray-900">
                    #{{ $booking['booking_number'] ?? $booking['id'] }}
                </span>

                <button
                    type="button"
                    onclick="copyBookingId()"
                    class="text-indigo-600 hover:text-indigo-700"
                    title="Copy booking ID"
                >
                    <svg
                        class="h-4 w-4"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                    >
                        <rect
                            x="9"
                            y="9"
                            width="13"
                            height="13"
                            rx="2"
                            stroke-width="2"
                        />

                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="2"
                            d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"
                        />
                    </svg>
                </button>

            </div>

        </div>
    </section>


    {{-- Main Content --}}
    <div class="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">

        {{-- Quick Status --}}
        <div class="grid grid-cols-1 gap-4 sm:grid-cols-3">

            {{-- Date --}}
            <div class="rounded-2xl border border-gray-200 bg-white p-5 shadow-sm">
                <div class="flex items-center gap-3">

                    <div class="flex h-11 w-11 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600">
                        <svg
                            class="h-5 w-5"
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                        >
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                stroke-width="2"
                                d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                            />
                        </svg>
                    </div>

                    <div>
                        <p class="text-xs text-gray-500">
                            Service Date
                        </p>

                        <p class="mt-1 text-sm font-bold text-gray-900">
                            {{ \Carbon\Carbon::parse($booking['slot_date'])->format('d F Y') }}
                        </p>

                        <p class="mt-0.5 text-xs text-gray-500">
                            {{ \Carbon\Carbon::parse($booking['slot_date'])->format('l') }}
                        </p>
                    </div>

                </div>
            </div>


            {{-- Time --}}
            <div class="rounded-2xl border border-gray-200 bg-white p-5 shadow-sm">
                <div class="flex items-center gap-3">

                    <div class="flex h-11 w-11 items-center justify-center rounded-xl bg-purple-50 text-purple-600">
                        <svg
                            class="h-5 w-5"
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                        >
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                stroke-width="2"
                                d="M12 6v6l4 2m6-2a10 10 0 11-20 0 10 10 0 0120 0z"
                            />
                        </svg>
                    </div>

                    <div>
                        <p class="text-xs text-gray-500">
                            Service Time
                        </p>

                        <p class="mt-1 text-sm font-bold text-gray-900">
                            {{ \Carbon\Carbon::parse($booking['slot_time'])->format('h:i A') }}
                        </p>
                    </div>

                </div>
            </div>


            {{-- Status --}}
            <div class="rounded-2xl border border-gray-200 bg-white p-5 shadow-sm">
                <div class="flex items-center gap-3">

                    <div class="flex h-11 w-11 items-center justify-center rounded-xl bg-green-50 text-green-600">
                        <svg
                            class="h-5 w-5"
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                        >
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                stroke-width="2"
                                d="M5 13l4 4L19 7"
                            />
                        </svg>
                    </div>

                    <div>
                        <p class="text-xs text-gray-500">
                            Booking Status
                        </p>

                        <p class="mt-1 text-sm font-bold text-green-600">
                            {{ ucfirst(str_replace('_', ' ', $booking['status'] ?? 'pending')) }}
                        </p>
                    </div>

                </div>
            </div>

        </div>


        <div class="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-3">

            {{-- Left --}}
            <div class="space-y-6 lg:col-span-2">

                {{-- Service Details --}}
                <div class="rounded-2xl border border-gray-200 bg-white shadow-sm">

                    <div class="flex items-center justify-between border-b border-gray-100 px-5 py-4">

                        <h2 class="font-semibold text-gray-900">
                            Service Details
                        </h2>

                        <span class="rounded-full bg-green-100 px-3 py-1 text-xs font-semibold text-green-700">
                            {{ ucfirst(str_replace('_', ' ', $booking['status'] ?? 'pending')) }}
                        </span>

                    </div>

                    <div class="p-5">

                        @forelse($booking['booking_items'] ?? [] as $item)

                            <div class="flex flex-col gap-5 sm:flex-row">

                                <div class="flex h-20 w-20 shrink-0 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-600">

                                    <svg
                                        class="h-9 w-9"
                                        fill="none"
                                        stroke="currentColor"
                                        viewBox="0 0 24 24"
                                    >
                                        <path
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                            stroke-width="1.7"
                                            d="M3 10.5V21h18V10.5M5 10.5L12 4l7 6.5M9 21v-6h6v6"
                                        />
                                    </svg>

                                </div>


                                <div class="flex-1">

                                    <p class="text-xs font-medium uppercase tracking-wide text-indigo-600">
                                        Service
                                    </p>

                                    <h3 class="mt-1 text-xl font-bold text-gray-900">
                                        {{ $item['package_name'] ?? 'Service' }}
                                    </h3>

                                    @if(!empty($item['variant_name']))
                                        <p class="mt-1 text-sm text-gray-500">
                                            {{ $item['variant_name'] }}
                                        </p>
                                    @endif

                                    @if(!empty($item['selections_summary']))
                                        <p class="mt-2 text-sm text-gray-500">
                                            {{ $item['selections_summary'] }}
                                        </p>
                                    @endif

                                    <div class="mt-3 flex flex-wrap gap-4 text-sm text-gray-500">

                                        <span class="flex items-center gap-1.5">
                                            <svg
                                                class="h-4 w-4"
                                                fill="none"
                                                stroke="currentColor"
                                                viewBox="0 0 24 24"
                                            >
                                                <path
                                                    stroke-linecap="round"
                                                    stroke-linejoin="round"
                                                    stroke-width="2"
                                                    d="M12 6v6l4 2m6-2a10 10 0 11-20 0 10 10 0 0120 0z"
                                                />
                                            </svg>

                                            Qty: {{ $item['quantity'] ?? 1 }}
                                        </span>

                                        <span class="flex items-center gap-1.5">
                                            ₹{{ number_format((float) ($item['unit_price'] ?? 0), 2) }} / item
                                        </span>

                                    </div>

                                </div>


                                <div class="text-left sm:text-right">

                                    <p class="text-xs text-gray-500">
                                        Item Total
                                    </p>

                                    <p class="mt-1 text-lg font-bold text-gray-900">
                                        ₹{{ number_format(
                                            (float) ($item['unit_price'] ?? 0) *
                                            (int) ($item['quantity'] ?? 1),
                                            2
                                        ) }}
                                    </p>

                                </div>

                            </div>

                            @if(!$loop->last)
                                <div class="my-5 border-t border-gray-100"></div>
                            @endif

                        @empty

                            <div class="py-6 text-center text-sm text-gray-500">
                                No booking items found.
                            </div>

                        @endforelse

                    </div>

                </div>


                {{-- Schedule --}}
                <div class="rounded-2xl border border-gray-200 bg-white shadow-sm">

                    <div class="border-b border-gray-100 px-5 py-4">
                        <h2 class="font-semibold text-gray-900">
                            Service Schedule
                        </h2>
                    </div>

                    <div class="grid grid-cols-1 gap-4 p-5 sm:grid-cols-2">

                        {{-- Date --}}
                        <div class="rounded-xl bg-gray-50 p-4">

                            <div class="flex items-center gap-3">

                                <div class="flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600">

                                    <svg
                                        class="h-5 w-5"
                                        fill="none"
                                        stroke="currentColor"
                                        viewBox="0 0 24 24"
                                    >
                                        <path
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                            stroke-width="2"
                                            d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                                        />
                                    </svg>

                                </div>

                                <div>

                                    <p class="text-xs text-gray-500">
                                        Date
                                    </p>

                                    <p class="mt-1 text-sm font-semibold text-gray-900">
                                        {{ \Carbon\Carbon::parse($booking['slot_date'])->format('l') }}
                                    </p>

                                    <p class="text-xs text-gray-500">
                                        {{ \Carbon\Carbon::parse($booking['slot_date'])->format('d F Y') }}
                                    </p>

                                </div>

                            </div>

                        </div>


                        {{-- Time --}}
                        <div class="rounded-xl bg-gray-50 p-4">

                            <div class="flex items-center gap-3">

                                <div class="flex h-10 w-10 items-center justify-center rounded-lg bg-purple-50 text-purple-600">

                                    <svg
                                        class="h-5 w-5"
                                        fill="none"
                                        stroke="currentColor"
                                        viewBox="0 0 24 24"
                                    >
                                        <path
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                            stroke-width="2"
                                            d="M12 6v6l4 2m6-2a10 10 0 11-20 0 10 10 0 0120 0z"
                                        />
                                    </svg>

                                </div>

                                <div>

                                    <p class="text-xs text-gray-500">
                                        Time
                                    </p>

                                    <p class="mt-1 text-sm font-semibold text-gray-900">
                                        {{ \Carbon\Carbon::parse($booking['slot_time'])->format('h:i A') }}
                                    </p>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>


                {{-- Customer / Address --}}
                <div class="rounded-2xl border border-gray-200 bg-white shadow-sm">

                    <div class="border-b border-gray-100 px-5 py-4">
                        <h2 class="font-semibold text-gray-900">
                            Service Address
                        </h2>
                    </div>

                    <div class="p-5">

                        <div class="flex gap-4">

                            <div class="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600">

                                <svg
                                    class="h-5 w-5"
                                    fill="none"
                                    stroke="currentColor"
                                    viewBox="0 0 24 24"
                                >
                                    <path
                                        stroke-linecap="round"
                                        stroke-linejoin="round"
                                        stroke-width="2"
                                        d="M3 10.5V21h18V10.5M5 10.5L12 4l7 6.5M9 21v-6h6v6"
                                    />
                                </svg>

                            </div>

                            <div class="flex-1">

                                <div class="flex flex-wrap items-center gap-2">

                                    <h3 class="font-semibold text-gray-900">
                                        Service Location
                                    </h3>

                                    <span class="rounded-full bg-gray-100 px-2 py-0.5 text-xs font-medium text-gray-600">
                                        Customer Address
                                    </span>

                                </div>

                                <p class="mt-1 text-sm font-medium text-gray-700">
                                    {{ $booking['name'] ?? '' }}
                                </p>

                                <p class="mt-1 text-sm leading-6 text-gray-500">
                                    {{ $booking['address'] ?? 'Address not available' }}
                                </p>

                                @if(!empty($booking['phone_number']))
                                    <p class="mt-2 text-sm text-gray-500">
                                        {{ $booking['phone_number'] }}
                                    </p>
                                @endif

                            </div>

                        </div>

                    </div>

                </div>


                {{-- Additional Services --}}
                <div class="rounded-2xl border border-gray-200 bg-white shadow-sm">

                    <div class="border-b border-gray-100 px-5 py-4">
                        <h2 class="font-semibold text-gray-900">
                            Additional Services
                        </h2>
                    </div>

                    <div class="divide-y divide-gray-100">

                        @forelse($booking['extraWorks'] ?? [] as $extra)

                            <div class="flex items-center justify-between px-5 py-4">

                                <div class="flex items-center gap-3">

                                    <div class="flex h-9 w-9 items-center justify-center rounded-lg bg-green-50 text-green-600">

                                        <svg
                                            class="h-5 w-5"
                                            fill="none"
                                            stroke="currentColor"
                                            viewBox="0 0 24 24"
                                        >
                                            <path
                                                stroke-linecap="round"
                                                stroke-linejoin="round"
                                                stroke-width="2"
                                                d="M5 13l4 4L19 7"
                                            />
                                        </svg>

                                    </div>

                                    <span class="text-sm font-medium text-gray-800">
                                        {{ $extra['name'] ?? $extra['title'] ?? 'Additional Service' }}
                                    </span>

                                </div>

                                @if(isset($extra['price']))
                                    <span class="text-sm font-semibold text-gray-900">
                                        ₹{{ number_format((float) $extra['price'], 2) }}
                                    </span>
                                @endif

                            </div>

                        @empty

                            <div class="px-5 py-5 text-sm text-gray-500">
                                No additional services added.
                            </div>

                        @endforelse

                    </div>

                </div>

            </div>


            {{-- Right --}}
            <div class="space-y-6">

                {{-- Payment --}}
                <div class="rounded-2xl border border-gray-200 bg-white shadow-sm">

                    <div class="border-b border-gray-100 px-5 py-4">
                        <h2 class="font-semibold text-gray-900">
                            Payment Details
                        </h2>
                    </div>

                    <div class="p-5">

                        <div class="flex items-center justify-between">

                            <div>

                                <p class="text-xs text-gray-500">
                                    Booking Status
                                </p>

                                <div class="mt-1 flex items-center gap-2">

                                    <span class="h-2 w-2 rounded-full bg-green-500"></span>

                                    <span class="text-sm font-semibold text-green-600">
                                        {{ ucfirst(str_replace('_', ' ', $booking['status'] ?? 'pending')) }}
                                    </span>

                                </div>

                            </div>

                            <div class="text-right">

                                <p class="text-xs text-gray-500">
                                    Amount
                                </p>

                                <p class="mt-1 text-xl font-bold text-gray-900">
                                    ₹{{ number_format((float) ($booking['total'] ?? 0), 2) }}
                                </p>

                            </div>

                        </div>

                        <div class="mt-5 border-t border-gray-100 pt-4">

                            <div class="flex items-center justify-between text-sm">

                                <span class="text-gray-500">
                                    Booking Number
                                </span>

                                <span class="font-medium text-gray-900">
                                    {{ $booking['booking_number'] ?? '-' }}
                                </span>

                            </div>

                            @if(!empty($booking['created_at']))

                                <div class="mt-3 flex items-center justify-between text-sm">

                                    <span class="text-gray-500">
                                        Created
                                    </span>

                                    <span class="font-medium text-gray-900">
                                        {{ \Carbon\Carbon::parse($booking['created_at'])->format('d M Y, h:i A') }}
                                    </span>

                                </div>

                            @endif

                        </div>

                    </div>

                </div>


                {{-- Price Breakdown --}}
                <div class="rounded-2xl border border-gray-200 bg-white shadow-sm">

                    <div class="border-b border-gray-100 px-5 py-4">
                        <h2 class="font-semibold text-gray-900">
                            Price Summary
                        </h2>
                    </div>

                    <div class="space-y-3 p-5">

                        <div class="flex justify-between text-sm">

                            <span class="text-gray-600">
                                Subtotal
                            </span>

                            <span class="font-medium text-gray-900">
                                ₹{{ number_format((float) ($booking['subtotal'] ?? 0), 2) }}
                            </span>

                        </div>


                        @if((float) ($booking['discount'] ?? 0) > 0)

                            <div class="flex justify-between text-sm">

                                <span class="text-gray-600">
                                    Discount
                                </span>

                                <span class="font-medium text-green-600">
                                    -₹{{ number_format((float) $booking['discount'], 2) }}
                                </span>

                            </div>

                        @endif


                        <div class="flex justify-between text-sm">

                            <span class="text-gray-600">
                                Additional Services
                            </span>

                            <span class="font-medium text-gray-900">
                                ₹{{ number_format(
                                    collect($booking['extraWorks'] ?? [])->sum(function ($extra) {
                                        return (float) ($extra['price'] ?? 0);
                                    }),
                                    2
                                ) }}
                            </span>

                        </div>


                        <div class="border-t border-dashed border-gray-200 pt-4">

                            <div class="flex items-center justify-between">

                                <span class="font-semibold text-gray-900">
                                    Total
                                </span>

                                <span class="text-xl font-bold text-gray-900">
                                    ₹{{ number_format((float) ($booking['total'] ?? 0), 2) }}
                                </span>

                            </div>

                        </div>

                    </div>

                </div>


                {{-- Cancellation Status --}}
                @if(!empty($booking['cancellation_status']) && $booking['cancellation_status'] !== 'none')

                    <div class="rounded-2xl border border-red-100 bg-red-50 p-5">

                        <h3 class="font-semibold text-red-900">
                            Cancellation Status
                        </h3>

                        <p class="mt-2 text-sm text-red-700">
                            {{ ucfirst(str_replace('_', ' ', $booking['cancellation_status'])) }}
                        </p>

                    </div>

                @endif


                {{-- Vendor --}}
                @if(!empty($booking['vendor']))

                    <div class="rounded-2xl border border-gray-200 bg-white shadow-sm">

                        <div class="border-b border-gray-100 px-5 py-4">
                            <h2 class="font-semibold text-gray-900">
                                Service Professional
                            </h2>
                        </div>

                        <div class="p-5">

                            @if(is_array($booking['vendor']))

                                <p class="text-sm font-semibold text-gray-900">
                                    {{ $booking['vendor']['name'] ?? 'Assigned Professional' }}
                                </p>

                                @if(!empty($booking['vendor']['phone']))
                                    <p class="mt-2 text-sm text-gray-500">
                                        {{ $booking['vendor']['phone'] }}
                                    </p>
                                @endif

                            @else

                                <p class="text-sm font-semibold text-gray-900">
                                    {{ $booking['vendor'] }}
                                </p>

                            @endif

                        </div>

                    </div>

                @endif


                {{-- What's Next --}}
                <div class="rounded-2xl border border-indigo-100 bg-indigo-50 p-5">

                    <h3 class="font-semibold text-indigo-900">
                        What's next?
                    </h3>

                    <div class="mt-4 space-y-4">

                        <div class="flex gap-3">

                            <div class="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-indigo-600 text-xs font-bold text-white">
                                1
                            </div>

                            <p class="text-xs leading-5 text-indigo-800">
                                Our service professional will be assigned to your booking.
                            </p>

                        </div>


                        <div class="flex gap-3">

                            <div class="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-indigo-600 text-xs font-bold text-white">
                                2
                            </div>

                            <p class="text-xs leading-5 text-indigo-800">
                                You'll receive an update before the professional arrives.
                            </p>

                        </div>


                        <div class="flex gap-3">

                            <div class="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-indigo-600 text-xs font-bold text-white">
                                3
                            </div>

                            <p class="text-xs leading-5 text-indigo-800">
                                Sit back and let our professional take care of the service.
                            </p>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        {{-- Action Buttons --}}
        <div class="mt-8 flex flex-col gap-3 sm:flex-row sm:justify-center">

            <a
                href="{{ route('booking.index') }}"
                class="inline-flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-7 py-3.5 text-sm font-semibold text-white shadow-sm transition hover:bg-indigo-700"
            >

                <svg
                    class="h-5 w-5"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                >
                    <path
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"
                        d="M9 5l7 7-7 7"
                    />
                </svg>

                View My Bookings

            </a>


            <a
                href="{{ url('/') }}"
                class="inline-flex items-center justify-center gap-2 rounded-xl border border-gray-300 bg-white px-7 py-3.5 text-sm font-semibold text-gray-700 transition hover:bg-gray-50"
            >

                <svg
                    class="h-5 w-5"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                >
                    <path
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"
                        d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11v10a1 1 0 01-1 1h-3m-6 0h6"
                    />
                </svg>

                Back to Home

            </a>

        </div>


        {{-- Support --}}
        <div class="mt-8 text-center">

            <p class="text-sm text-gray-500">
                Need help with your booking?
                <a
                    href="#"
                    class="font-semibold text-indigo-600 hover:text-indigo-700"
                >
                    Contact Support
                </a>
            </p>

        </div>

    </div>

</div>


<script>
    function copyBookingId() {
        const bookingId = @json($booking['booking_number'] ?? $booking['id'] ?? '');

        if (navigator.clipboard) {
            navigator.clipboard.writeText(bookingId).then(() => {
                // Optional: replace with toast notification
                alert('Booking ID copied!');
            });
        }
    }
</script>

@endsection