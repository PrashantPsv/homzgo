@extends('layouts.app')

@section('title', 'My Bookings | ServiceHub')

@section('content')



{{-- ============================================================
     PAGE HEADER
============================================================ --}}

<section class="bg-white border-b border-gray-200">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">

        <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-5">

            <div>
                <div class="flex items-center gap-2 text-sm text-gray-500 mb-3">
                    <a href="{{ url('/') }}" class="hover:text-indigo-600 transition">
                        Home
                    </a>

                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round"
                              stroke-linejoin="round"
                              stroke-width="2"
                              d="M9 5l7 7-7 7"/>
                    </svg>

                    <span class="text-gray-900">My Bookings</span>
                </div>

                <h1 class="text-3xl sm:text-4xl font-bold text-gray-900">
                    My Bookings
                </h1>

                <p class="mt-2 text-gray-600">
                    View and manage all your ServiceHub bookings.
                </p>
            </div>

            <a
                href="{{ url('/services') }}"
                class="inline-flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 py-3 text-sm font-semibold text-white hover:bg-indigo-700 transition shadow-sm"
            >
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round"
                          stroke-linejoin="round"
                          stroke-width="2"
                          d="M12 5v14M5 12h14"/>
                </svg>

                Book a New Service
            </a>

        </div>

    </div>
</section>


{{-- ============================================================
     MAIN CONTENT
============================================================ --}}

<section class="py-8 sm:py-10">

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        {{-- ====================================================
             STAT CARDS
        ===================================================== --}}

        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">

            @foreach($stats as $stat)

                <div class="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm">

                    <div class="flex items-start justify-between gap-3">

                        <div>
                            <p class="text-sm text-gray-500">
                                {{ $stat['label'] }}
                            </p>

                            <p class="mt-2 text-2xl font-bold text-gray-900">
                                {{ $stat['value'] }}
                            </p>
                        </div>

                        <div class="{{ $stat['bg'] }} {{ $stat['text'] }} w-11 h-11 rounded-xl flex items-center justify-center">

                            @if($stat['icon'] === 'calendar')

                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round"
                                          stroke-linejoin="round"
                                          stroke-width="2"
                                          d="M8 7V3m8 4V3m-9 8h10M5 5h14a2 2 0 012 2v12a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2z"/>
                                </svg>

                            @elseif($stat['icon'] === 'clock')

                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <circle cx="12" cy="12" r="9" stroke-width="2"/>
                                    <path stroke-linecap="round"
                                          stroke-width="2"
                                          d="M12 7v5l3 2"/>
                                </svg>

                            @elseif($stat['icon'] === 'check')

                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round"
                                          stroke-linejoin="round"
                                          stroke-width="2"
                                          d="M5 13l4 4L19 7"/>
                                </svg>

                            @else

                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round"
                                          stroke-linejoin="round"
                                          stroke-width="2"
                                          d="M6 18L18 6M6 6l12 12"/>
                                </svg>

                            @endif

                        </div>

                    </div>

                </div>

            @endforeach

        </div>


        {{-- ====================================================
             BOOKING TABS
        ===================================================== --}}

        <div class="bg-white border border-gray-200 rounded-2xl shadow-sm overflow-hidden">

            <div class="border-b border-gray-200">

                <div class="flex overflow-x-auto">

                    <button
                        type="button"
                        class="px-5 sm:px-6 py-4 text-sm font-semibold text-indigo-600 border-b-2 border-indigo-600 whitespace-nowrap"
                    >
                        Upcoming
                        <span class="ml-1.5 text-xs bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded-full">
                            1
                        </span>
                    </button>

                    <button
                        type="button"
                        class="px-5 sm:px-6 py-4 text-sm font-medium text-gray-500 hover:text-gray-900 whitespace-nowrap"
                    >
                        Completed
                        <span class="ml-1.5 text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">
                            6
                        </span>
                    </button>

                    <button
                        type="button"
                        class="px-5 sm:px-6 py-4 text-sm font-medium text-gray-500 hover:text-gray-900 whitespace-nowrap"
                    >
                        Cancelled
                        <span class="ml-1.5 text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">
                            1
                        </span>
                    </button>

                </div>

            </div>


            {{-- =================================================
                 UPCOMING BOOKINGS
            ================================================== --}}

            <div class="p-4 sm:p-6">

                <div class="flex items-center justify-between mb-5">

                    <div>
                        <h2 class="text-lg font-bold text-gray-900">
                            Upcoming Bookings
                        </h2>

                        <p class="text-sm text-gray-500 mt-1">
                            Your scheduled services
                        </p>
                    </div>

                </div>


                @foreach($upcomingBookings as $booking)

                    <div class="border border-indigo-100 bg-indigo-50/30 rounded-2xl overflow-hidden">

                        {{-- Booking top bar --}}

                        <div class="px-4 sm:px-6 py-4 border-b border-indigo-100 bg-white">

                            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">

                                <div class="flex items-center gap-3">

                                    <span class="inline-flex items-center rounded-full bg-green-100 px-3 py-1 text-xs font-semibold text-green-700">
                                        {{ $booking['status'] }}
                                    </span>

                                    <span class="text-xs sm:text-sm text-gray-500">
                                        Booking #{{ $booking['id'] }}
                                    </span>

                                </div>

                                <span class="text-sm font-bold text-gray-900">
                                    ₹{{ number_format($booking['total']) }}
                                </span>

                            </div>

                        </div>


                        {{-- Booking content --}}

                        <div class="p-4 sm:p-6">

                            <div class="flex flex-col lg:flex-row gap-6">

                                {{-- Service --}}

                                <div class="flex-1">

                                    <div class="flex flex-col sm:flex-row gap-4">

                                        @if(isset($booking['image']) && !empty($booking['image']))
                                            <img
                                                src="{{ $booking['image'] }}"
                                                alt="{{ $booking['booking_number'] }}"
                                                class="w-full sm:w-32 h-40 sm:h-28 object-cover rounded-xl"
                                            >
                                        @else
                                            <div class="w-full sm:w-32 h-40 sm:h-28 rounded-xl bg-gray-100 flex items-center justify-center">
                                                <span class="text-gray-400 text-sm">No Image</span>
                                            </div>
                                        @endif

                                        <div class="flex-1">

                                            <p class="text-xs font-medium text-indigo-600 uppercase tracking-wide">
                                                {{ !empty($booking['category']) }}
                                            </p>

                                            <h3 class="mt-1 text-lg font-bold text-gray-900">
                                                {{ !empty($booking['service']) }}
                                            </h3>

                                            <div class="mt-3 space-y-2">

                                                <div class="flex items-center gap-2 text-sm text-gray-600">

                                                    <svg class="w-4 h-4 text-gray-400"
                                                         fill="none"
                                                         stroke="currentColor"
                                                         viewBox="0 0 24 24">
                                                        <path stroke-linecap="round"
                                                              stroke-linejoin="round"
                                                              stroke-width="2"
                                                              d="M8 7V3m8 4V3m-9 8h10M5 5h14a2 2 0 012 2v12a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2z"/>
                                                    </svg>

                                                    {{ date('D', strtotime($booking['slot_date'])) }}, {{ $booking['slot_date'] }}

                                                </div>

                                                <div class="flex items-center gap-2 text-sm text-gray-600">

                                                    <svg class="w-4 h-4 text-gray-400"
                                                         fill="none"
                                                         stroke="currentColor"
                                                         viewBox="0 0 24 24">
                                                        <circle cx="12" cy="12" r="9" stroke-width="2"/>
                                                        <path stroke-linecap="round"
                                                              stroke-width="2"
                                                              d="M12 7v5l3 2"/>
                                                    </svg>

                                                    {{ $booking['slot_time'] }}
                                                    

                                                </div>

                                                <div class="flex items-start gap-2 text-sm text-gray-600">

                                                    <svg class="w-4 h-4 text-gray-400 mt-0.5"
                                                         fill="none"
                                                         stroke="currentColor"
                                                         viewBox="0 0 24 24">
                                                        <path stroke-linecap="round"
                                                              stroke-linejoin="round"
                                                              stroke-width="2"
                                                              d="M12 21s7-5.4 7-11a7 7 0 10-14 0c0 5.6 7 11 7 11z"/>
                                                        <circle cx="12" cy="10" r="2.5"/>
                                                    </svg>

                                                    {{ $booking['address'] }}

                                                </div>

                                            </div>

                                        </div>

                                    </div>


                                    {{-- Addons --}}

                                    @if(count($booking['extraWorks']) > 0)

                                        <div class="mt-5 pt-4 border-t border-indigo-100">

                                            <p class="text-xs font-semibold text-gray-500 uppercase tracking-wide">
                                                Additional Services
                                            </p>

                                            <div class="flex flex-wrap gap-2 mt-2">

                                                @foreach($booking['extraWorks'] as $addon)

                                                    <span class="inline-flex items-center rounded-lg bg-white border border-gray-200 px-3 py-1.5 text-xs font-medium text-gray-700">
                                                        {{ $addon['name'] }}
                                                    </span>

                                                @endforeach

                                            </div>

                                        </div>

                                    @endif

                                </div>


                                {{-- Right booking information --}}

                                <div class="lg:w-64 lg:border-l lg:border-indigo-100 lg:pl-6">

                                    <div class="space-y-4">

                                        <div>
                                            <p class="text-xs text-gray-500">
                                                Payment
                                            </p>

                                            <p class="mt-1 text-sm font-semibold text-green-600">
                                                {{ $booking['subtotal'] }}
                                            </p>
                                        </div>

                                        <div>
                                            <p class="text-xs text-gray-500">
                                                Total Amount
                                            </p>

                                            <p class="mt-1 text-xl font-bold text-gray-900">
                                                ₹{{ number_format($booking['total']) }}
                                            </p>
                                        </div>

                                        <div class="pt-2">

                                            <a
                                                href="{{ route('booking.success', ['booking_id' => Crypt::encryptString($booking['id'])]) }}"
                                                class="block w-full rounded-xl bg-indigo-600 px-4 py-3 text-center text-sm font-semibold text-white hover:bg-indigo-700 transition"
                                            >
                                                View Booking Details
                                            </a>

                                            <div class="grid grid-cols-2 gap-2 mt-2">

                                                <button
                                                    type="button"
                                                    class="rounded-xl border border-gray-200 bg-white px-3 py-2.5 text-xs font-semibold text-gray-700 hover:bg-gray-50 transition"
                                                >
                                                    Reschedule
                                                </button>

                                                <button
                                                    type="button"
                                                    class="rounded-xl border border-gray-200 bg-white px-3 py-2.5 text-xs font-semibold text-red-600 hover:bg-red-50 transition"
                                                >
                                                    Cancel
                                                </button>

                                            </div>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                @endforeach


                {{-- =================================================
                     COMPLETED PREVIEW
                ================================================== --}}

                <div class="mt-10">

                    <div class="flex items-center justify-between mb-5">

                        <div>
                            <h2 class="text-lg font-bold text-gray-900">
                                Recent Completed Bookings
                            </h2>

                            <p class="text-sm text-gray-500 mt-1">
                                Your recently completed services
                            </p>
                        </div>

                        <button
                            type="button"
                            class="hidden sm:block text-sm font-semibold text-indigo-600 hover:text-indigo-700"
                        >
                            View All
                        </button>

                    </div>


                    <div class="space-y-4">

                        @foreach($completedBookings as $booking)

                            <div class="border border-gray-200 rounded-2xl p-4 sm:p-5 bg-white">

                                <div class="flex flex-col sm:flex-row gap-4">

                                    @if(isset($booking['image']) && !empty($booking['image']))
                                        <img
                                            src="{{ $booking['image'] }}"
                                            alt="{{ $booking['booking_number'] }}"
                                            class="w-full sm:w-32 h-40 sm:h-28 object-cover rounded-xl"
                                        >
                                    @else
                                        <div class="w-full sm:w-32 h-40 sm:h-28 rounded-xl bg-gray-100 flex items-center justify-center">
                                            <span class="text-gray-400 text-sm">No Image</span>
                                        </div>
                                    @endif

                                    <div class="flex-1">

                                        <div class="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2">

                                            <div>

                                                <span class="text-xs font-medium text-gray-500 uppercase tracking-wide">
                                                    {{ !empty($booking['category']) }}
                                                </span>

                                                <h3 class="mt-1 font-bold text-gray-900">
                                                    {{ !empty($booking['service']) }}
                                                </h3>

                                            </div>

                                            <span class="self-start inline-flex items-center rounded-full bg-green-50 px-3 py-1 text-xs font-semibold text-green-700">
                                                Completed
                                            </span>

                                        </div>


                                        <div class="mt-3 flex flex-col sm:flex-row sm:flex-wrap gap-2 sm:gap-5 text-sm text-gray-600">

                                            <span class="flex items-center gap-2">

                                                <svg class="w-4 h-4 text-gray-400"
                                                     fill="none"
                                                     stroke="currentColor"
                                                     viewBox="0 0 24 24">
                                                    <path stroke-linecap="round"
                                                          stroke-linejoin="round"
                                                          stroke-width="2"
                                                          d="M8 7V3m8 4V3m-9 8h10M5 5h14a2 2 0 012 2v12a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2z"/>
                                                </svg>

                                                {{ $booking['slot_date'] }}

                                            </span>

                                            <span class="flex items-center gap-2">

                                                <svg class="w-4 h-4 text-gray-400"
                                                     fill="none"
                                                     stroke="currentColor"
                                                     viewBox="0 0 24 24">
                                                    <circle cx="12" cy="12" r="9" stroke-width="2"/>
                                                    <path stroke-linecap="round"
                                                          stroke-width="2"
                                                          d="M12 7v5l3 2"/>
                                                </svg>

                                                {{ $booking['slot_time'] }}

                                            </span>

                                            <span>
                                                ₹{{ number_format($booking['total']) }}
                                            </span>

                                        </div>

                                    </div>


                                    <div class="flex sm:flex-col items-center sm:items-end justify-between gap-2">

                                        @if($booking['rating'])

                                            <div class="flex items-center gap-1 text-sm">

                                                <svg class="w-4 h-4 fill-current text-yellow-400"
                                                     viewBox="0 0 20 20">
                                                    <path d="M10 15l-5.878 3.09 1.123-6.545L.49 6.91l6.56-.955L10 0l2.95 5.955 6.56.955-4.755 4.635 1.123 6.545z"/>
                                                </svg>

                                                <span class="font-semibold text-gray-900">
                                                    {{ $booking['rating'] }}.0
                                                </span>

                                            </div>

                                        @else

                                            <button
                                                type="button"
                                                class="text-sm font-semibold text-indigo-600 hover:text-indigo-700"
                                            >
                                                Rate Service
                                            </button>

                                        @endif

                                        <a
                                            href="{{ route('booking.success', ['booking_id' => Crypt::encryptString($booking['id'])]) }}"
                                            class="text-sm font-semibold text-gray-600 hover:text-gray-900"
                                        >
                                            View Details
                                        </a>

                                    </div>

                                </div>

                            </div>

                        @endforeach

                    </div>

                </div>


                {{-- =================================================
                     CANCELLED PREVIEW
                ================================================== --}}

                <div class="mt-10">

                    <div class="flex items-center justify-between mb-5">

                        <div>
                            <h2 class="text-lg font-bold text-gray-900">
                                Cancelled Booking
                            </h2>

                            <p class="text-sm text-gray-500 mt-1">
                                Recently cancelled services
                            </p>
                        </div>

                    </div>


                    @foreach($cancelledBookings as $booking)

                        <div class="border border-gray-200 rounded-2xl p-4 sm:p-5 bg-gray-50">

                            <div class="flex flex-col sm:flex-row gap-4">

                                @if(isset($booking['image']) && !empty($booking['image']))
                                    <img
                                        src="{{ $booking['image'] }}"
                                        alt="{{ $booking['booking_number'] }}"
                                        class="w-full sm:w-32 h-40 sm:h-28 object-cover rounded-xl"
                                    >
                                @else
                                    <div class="w-full sm:w-32 h-40 sm:h-28 rounded-xl bg-gray-100 flex items-center justify-center">
                                        <span class="text-gray-400 text-sm">No Image</span>
                                    </div>
                                @endif

                                <div class="flex-1">

                                    <div class="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2">

                                        <div>

                                            <span class="text-xs font-medium text-gray-500 uppercase tracking-wide">
                                                {{ !empty($booking['category']) }}
                                            </span>

                                            <h3 class="mt-1 font-bold text-gray-700">
                                                {{ !empty($booking['service']) }}
                                            </h3>

                                        </div>

                                        <span class="self-start inline-flex items-center rounded-full bg-red-50 px-3 py-1 text-xs font-semibold text-red-600">
                                            Cancelled
                                        </span>

                                    </div>

                                    <div class="mt-3 text-sm text-gray-500 space-y-1">

                                        <p>
                                            {{ $booking['slot_date'] }} · {{ $booking['slot_time'] }}
                                        </p>

                                        <p>
                                            {{ $booking['reason'] }}
                                        </p>

                                    </div>

                                </div>

                                <div class="flex sm:flex-col sm:items-end justify-between gap-2">

                                    <span class="text-sm font-semibold text-gray-600">
                                        ₹{{ number_format($booking['total']) }}
                                    </span>

                                    <a
                                        href="{{ route('booking.success', ['booking_id' => Crypt::encryptString($booking['id'])]) }}"
                                        class="text-sm font-semibold text-gray-500 hover:text-gray-900"
                                    >
                                        View Details
                                    </a>

                                </div>

                            </div>

                        </div>

                    @endforeach

                </div>

            </div>

        </div>


        {{-- ====================================================
             HELP / CTA
        ===================================================== --}}

        <div class="mt-8 rounded-2xl bg-indigo-600 p-6 sm:p-8">

            <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-6">

                <div>

                    <h2 class="text-xl font-bold text-white">
                        Need help with a booking?
                    </h2>

                    <p class="mt-2 text-sm text-indigo-100 max-w-xl">
                        Our support team is here to help you with rescheduling,
                        cancellations, payments and service-related questions.
                    </p>

                </div>

                <a
                    href="#"
                    class="inline-flex items-center justify-center gap-2 rounded-xl bg-white px-5 py-3 text-sm font-semibold text-indigo-600 hover:bg-indigo-50 transition whitespace-nowrap"
                >
                    Contact Support

                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round"
                              stroke-linejoin="round"
                              stroke-width="2"
                              d="M9 5l7 7-7 7"/>
                    </svg>
                </a>

            </div>

        </div>

    </div>

</section>

@endsection