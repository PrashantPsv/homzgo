<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>@yield('title', 'Home Services')</title>

    <script src="https://cdn.tailwindcss.com"></script>

   
    
    <meta name="csrf-token" content="{{ csrf_token() }}">
    
    @vite(['resources/css/app.css', 'resources/js/app.js'])

    @stack('styles')
</head>

<body class="bg-gray-50 text-gray-900 antialiased">

    @include('layouts.header')

    <main>
        @yield('content')
    </main>

    @include('layouts.footer')

    @include('components.login-modal')

    @stack('scripts')
    <script type="text/javascript">
        window.openLocationModal = function () {
            const modal = document.getElementById('location-picker');

            if (!modal) {
                console.error('Location modal not found.');
                return;
            }

            modal.classList.remove('hidden');
            document.body.classList.add('overflow-hidden');

            const input = document.getElementById('locationSearch');

            if (input) {
                setTimeout(() => input.focus(), 100);
            }
        };

        window.closeLocationModal = function () {
            const modal = document.getElementById('location-picker');

            if (!modal) {
                return;
            }

            modal.classList.add('hidden');
            document.body.classList.remove('overflow-hidden');
        };
    </script>
</body>
</html>