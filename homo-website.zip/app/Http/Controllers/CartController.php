<?php

namespace App\Http\Controllers;

use App\Services\CatalogApiService;
use Illuminate\Http\Request;

class CartController extends Controller
{
    public function cart(CatalogApiService $catalogApi)
    {
        try {
            $guestToken = $this->ensureGuestToken($catalogApi);
            $cartResponse = $catalogApi->cart($guestToken);
            $cart = $cartResponse['data']['cart_groups'] ?? [];
            $items = $cart[0]['items'] ?? (is_array($cart) && array_is_list($cart) ? $cart : []);
            $items = array_map(fn($item) => $this->normalizeItem((array) $item), $items);
            return view('cart.index', [
                'cart' => $cart,
                'cartItems' => $items,
                'guestToken' => $guestToken,
                'catalogUser' => session('catalog_user'),
            ]);
        } catch (\Throwable $e) {
            report($e);
            return view('cart.index', ['cart'=>[],'cartItems'=>[],'guestToken'=>session('catalog_guest_token'),'catalogUser'=>session('catalog_user'),'apiError'=>'Unable to load cart.']);
        }
    }

    public function store(Request $request, CatalogApiService $catalogApi)
    {
        $data = $request->validate([
            'package_id' => ['required','integer'],
            'quantity' => ['required','integer','min:1'],
            'guest_token' => ['nullable','string','max:255'],
            'variant_id' => ['nullable','integer'],
            'selections' => ['nullable'],
            'section_selections' => ['nullable'],
        ]);
        try {
            $guest = $data['guest_token'] ?? $this->ensureGuestToken($catalogApi);
            return response()->json($catalogApi->addToCart($data['package_id'], $data['quantity'], $guest, $data['variant_id'] ?? null, $data['selections'] ?? null, $data['section_selections'] ?? null));
        } catch (\Throwable $e) { report($e); return response()->json(['status'=>false,'message'=>'Unable to add item to cart.','data'=>null],500); }
    }

    public function update(Request $request, int|string $item, CatalogApiService $catalogApi)
    {
        $data = $request->validate(['quantity'=>['required','integer','min:1'],'guest_token'=>['nullable','string'],'slot_date'=>['nullable','date'],'slot_time'=>['nullable','string']]);
        try { return response()->json($catalogApi->updateCartItem($item,(int)$data['quantity'],$data['guest_token'] ?? session('catalog_guest_token'), array_filter(['slot_date'=>$data['slot_date'] ?? null,'slot_time'=>$data['slot_time'] ?? null]))); }
        catch (\Throwable $e) { report($e); return response()->json(['status'=>false,'message'=>'Unable to update cart item.','data'=>null],500); }
    }

    public function destroy(Request $request, int|string $item, CatalogApiService $catalogApi)
    {
        try { return response()->json($catalogApi->deleteCartItem($item, $request->input('guest_token') ?? session('catalog_guest_token'))); }
        catch (\Throwable $e) { report($e); return response()->json(['status'=>false,'message'=>'Unable to remove cart item.','data'=>null],500); }
    }

    private function normalizeItem(array $item): array
    {
        $package = is_array($item['package'] ?? null) ? $item['package'] : [];
        return array_merge($item, [
            'cart_item_id' => $item['cart_item_id'] ?? $item['cart_item_id'] ?? $item['id'] ?? null,
            'package_id' => $item['package_id'] ?? $package['id'] ?? $item['id'] ?? null,
            'id' => $item['package_id'] ?? $package['id'] ?? $item['id'] ?? null,
            'name' => $item['name'] ?? $package['name'] ?? $item['package_name'] ?? 'Service',
            'price' => (float)($item['price'] ?? $item['unit_price'] ?? $package['price'] ?? 0),
            'quantity' => (int)($item['quantity'] ?? 1),
            'thumbnail_image' => $item['thumbnail_image'] ?? $package['thumbnail_image'] ?? $package['image'] ?? $package['image_url'] ?? null,
        ]);
    }

    private function ensureGuestToken(CatalogApiService $catalogApi): string
    {
        if ($token = session('catalog_guest_token')) return $token;
        try {
            $response = $catalogApi->guestToken();
            $data = $response['data'] ?? [];
            $token = $data['guest_token'] ?? $data['token'] ?? $response['guest_token'] ?? $response['token'] ?? null;
            if ($token) {
                session(['catalog_guest_token'=>$token]);
                return $token;
            }
        } catch (\Throwable $e) { report($e); }
        $token = (string) \Illuminate\Support\Str::uuid();
        session(['catalog_guest_token'=>$token]);
        return $token;
    }
}
