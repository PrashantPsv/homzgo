<?php

namespace App\Http\Controllers;

use App\Services\CatalogApiService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;

class PaymentController extends Controller
{
    public function createOrder(Request $request, CatalogApiService $api)
    {
        $amount=(float)$request->input('amount');
        if($amount<=0) return response()->json(['success'=>false,'message'=>'Invalid payment amount.'],422);
        try {
            $order=(new Api(config('services.razorpay.key'),config('services.razorpay.secret')))->order->create([
                'receipt'=>'BOOK_'.now()->format('YmdHis').'_'.random_int(1000,9999),
                'amount'=>(int)round($amount*100),'currency'=>'INR','payment_capture'=>1,
            ]);
            return response()->json(['success'=>true,'order_id'=>$order['id'],'amount'=>$order['amount'],'currency'=>$order['currency'],'key'=>config('services.razorpay.key'),'receipt'=>$order['receipt'] ?? null]);
        } catch (\Throwable $e) { report($e); return response()->json(['success'=>false,'message'=>'Unable to create payment order.'],500); }
    }

    public function verifyPayment(Request $request,CatalogApiService $api)
    {
        $v=$request->validate(['razorpay_order_id'=>'required|string','razorpay_payment_id'=>'required|string','razorpay_signature'=>'required|string','address_id'=>'required','slots'=>'required']);
        try {
            $razor=(new Api(config('services.razorpay.key'),config('services.razorpay.secret')));
            $razor->utility->verifyPaymentSignature([
                'razorpay_order_id'=>$v['razorpay_order_id'],'razorpay_payment_id'=>$v['razorpay_payment_id'],'razorpay_signature'=>$v['razorpay_signature'],
            ]);
            $checkout=$api->checkout($v['address_id'],$v['slots']);
            $bookingId=data_get($checkout,'data.bookings.0.id') ?? data_get($checkout,'data.booking.id') ?? data_get($checkout,'data.id');
            if(!$bookingId) throw new \RuntimeException('Booking was not returned by checkout API.');
            return response()->json(['success'=>true,'message'=>'Payment verified successfully.','checkout'=>$checkout,'redirect'=>route('booking.success',['booking_id'=>Crypt::encryptString((string)$bookingId)])]);
        } catch(SignatureVerificationError $e){ return response()->json(['success'=>false,'message'=>'Razorpay signature verification failed.'],400); }
          catch(\Throwable $e){ report($e); return response()->json(['success'=>false,'message'=>'Unable to verify payment.'],500); }
    }
}
