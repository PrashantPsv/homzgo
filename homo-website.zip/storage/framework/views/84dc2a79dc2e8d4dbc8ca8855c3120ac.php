<?php $__env->startSection('title', 'Home | ServiceHub'); ?>

<?php $__env->startSection('content'); ?>
<div x-data="serviceCategoryModal()">
    
    <section class="relative overflow-hidden bg-white">

        <div class="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-20 lg:px-8 lg:py-24">

            <div class="grid items-center gap-12 lg:grid-cols-2">

                
                <div>

                    
                    <div class="mb-6 inline-flex items-center gap-2 rounded-full bg-gray-100 px-4 py-2 text-sm font-medium text-gray-700">
                        <span class="h-2 w-2 rounded-full bg-green-500"></span>

                        Trusted home services
                    </div>

                    
                    <h1 class="max-w-2xl text-4xl font-bold leading-tight tracking-tight text-gray-900 sm:text-5xl lg:text-6xl">

                        Home services
                        <span class="text-gray-400">
                            at your doorstep.
                        </span>

                    </h1>

                    
                    <p class="mt-6 max-w-xl text-base leading-7 text-gray-500 sm:text-lg">
                        Book trusted professionals for cleaning, repairs,
                        maintenance and other services — whenever you need them.
                    </p>

                    
                    <div class="mt-8 max-w-2xl">

                        <div class="flex flex-col overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-lg sm:flex-row">

                            
                            <button
                                type="button"
                                onclick="window.openLocationPicker && window.openLocationPicker()"
                                class="flex items-center gap-3 border-b border-gray-200 px-5 py-4 text-left sm:w-44 sm:border-b-0 sm:border-r"
                            >

                                <svg
                                    class="h-5 w-5 shrink-0 text-gray-700"
                                    fill="none"
                                    stroke="currentColor"
                                    viewBox="0 0 24 24"
                                >
                                    <path
                                        stroke-linecap="round"
                                        stroke-linejoin="round"
                                        stroke-width="2"
                                        d="M17.657 16.657L13.414 21.9a1 1 0 01-1.414 0l-4.243-5.243a8 8 0 1110.9 0z"
                                    />

                                    <path
                                        stroke-linecap="round"
                                        stroke-linejoin="round"
                                        stroke-width="2"
                                        d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                                    />
                                </svg>

                                <div>
                                    <span class="block text-xs text-gray-400">
                                        Location
                                    </span>

                                    <span class="block text-sm font-semibold text-gray-800">
                                        <?php echo e($location['address'] ?? 'Select Location'); ?>

                                    </span>
                                </div>

                            </button>

                            
                            <div class="flex flex-1 items-center gap-3 px-5 py-4">

                                <svg
                                    class="h-5 w-5 shrink-0 text-gray-400"
                                    fill="none"
                                    stroke="currentColor"
                                    viewBox="0 0 24 24"
                                >
                                    <path
                                        stroke-linecap="round"
                                        stroke-linejoin="round"
                                        stroke-width="2"
                                        d="M21 21l-4.35-4.35m2.35-5.65a8 8 0 11-16 0 8 8 0 0116 0z"
                                    />
                                </svg>

                                <input
                                    type="text"
                                    placeholder="Search for a service"
                                    class="w-full border-0 bg-transparent text-sm outline-none placeholder:text-gray-400 focus:ring-0"
                                />

                                <button
                                    type="button"
                                    class="hidden rounded-xl bg-black px-5 py-3 text-sm font-semibold text-white transition hover:bg-gray-800 sm:block"
                                >
                                    Search
                                </button>

                            </div>

                        </div>

                    </div>

                    
                    <div class="mt-5 flex flex-wrap items-center gap-2">

                        <span class="text-sm text-gray-400">
                            Popular:
                        </span>

                        <button class="rounded-full border border-gray-200 px-3 py-1.5 text-xs font-medium text-gray-600 hover:bg-gray-100">
                            Home Cleaning
                        </button>

                        <button class="rounded-full border border-gray-200 px-3 py-1.5 text-xs font-medium text-gray-600 hover:bg-gray-100">
                            AC Service
                        </button>

                        <button class="rounded-full border border-gray-200 px-3 py-1.5 text-xs font-medium text-gray-600 hover:bg-gray-100">
                            Plumbing
                        </button>

                    </div>

                </div>


                
                <div class="relative hidden lg:block">

                    
                    <div class="absolute -right-10 -top-10 h-72 w-72 rounded-full bg-gray-100"></div>

                    
                    <div class="relative mx-auto max-w-md">

                        <div class="overflow-hidden rounded-3xl bg-gray-100">

                            
                            <div class="flex h-[430px] items-center justify-center">

                                <div class="text-center">

                                    <div class="mx-auto flex h-28 w-28 items-center justify-center rounded-full bg-white shadow-sm">

                                        <svg
                                            class="h-14 w-14 text-gray-400"
                                            fill="none"
                                            stroke="currentColor"
                                            viewBox="0 0 24 24"
                                        >
                                            <path
                                                stroke-linecap="round"
                                                stroke-linejoin="round"
                                                stroke-width="1.5"
                                                d="M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.6-3.6a6 6 0 01-7.6 7.6L7 19.9a2.1 2.1 0 01-3-3l6.6-7.6a6 6 0 017.6-7.6l-3.5 3.6z"
                                            />
                                        </svg>

                                    </div>

                                    <p class="mt-5 text-sm font-medium text-gray-500">
                                        Professional services
                                    </p>

                                </div>

                            </div>

                        </div>


                        
                        <div class="absolute -bottom-6 -left-8 w-64 rounded-2xl bg-white p-4 shadow-xl">

                            <div class="flex items-center gap-3">

                                <div class="flex h-11 w-11 items-center justify-center rounded-xl bg-gray-100">

                                    <svg
                                        class="h-5 w-5 text-gray-700"
                                        fill="none"
                                        stroke="currentColor"
                                        viewBox="0 0 24 24"
                                    >
                                        <path
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                            stroke-width="2"
                                            d="M5 13l4 4L19 7"
                                        />
                                    </svg>

                                </div>

                                <div>
                                    <p class="text-xs text-gray-400">
                                        Booking confirmed
                                    </p>

                                    <p class="text-sm font-semibold text-gray-900">
                                        Service booked
                                    </p>
                                </div>

                            </div>

                        </div>


                        
                        <div class="absolute -right-6 top-20 rounded-2xl bg-white px-4 py-3 shadow-xl">

                            <div class="flex items-center gap-2">

                                <div class="flex h-9 w-9 items-center justify-center rounded-full bg-black text-sm font-bold text-white">
                                    ★
                                </div>

                                <div>
                                    <p class="text-sm font-bold text-gray-900">
                                        4.8
                                    </p>

                                    <p class="text-xs text-gray-400">
                                        Customer rating
                                    </p>
                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </section>

    
    <section class="border-y border-gray-100 bg-white">

        <div class="mx-auto grid max-w-7xl grid-cols-2 divide-x divide-gray-100 sm:grid-cols-4">

            <div class="px-4 py-6 text-center">
                <p class="text-2xl font-bold text-gray-900">
                    10K+
                </p>

                <p class="mt-1 text-xs text-gray-500 sm:text-sm">
                    Happy customers
                </p>
            </div>

            <div class="px-4 py-6 text-center">
                <p class="text-2xl font-bold text-gray-900">
                    500+
                </p>

                <p class="mt-1 text-xs text-gray-500 sm:text-sm">
                    Professionals
                </p>
            </div>

            <div class="border-t border-gray-100 px-4 py-6 text-center sm:border-t-0">
                <p class="text-2xl font-bold text-gray-900">
                    50+
                </p>

                <p class="mt-1 text-xs text-gray-500 sm:text-sm">
                    Services
                </p>
            </div>

            <div class="border-t border-gray-100 px-4 py-6 text-center sm:border-t-0">
                <p class="text-2xl font-bold text-gray-900">
                    4.8★
                </p>

                <p class="mt-1 text-xs text-gray-500 sm:text-sm">
                    Average rating
                </p>
            </div>

        </div>

    </section>

    
    <section id="services" class="bg-gray-50 py-16">

        <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">

            <div class="flex items-end justify-between">

                <div>
                    <p class="text-sm font-semibold uppercase tracking-wider text-gray-400">
                        Explore
                    </p>

                    <h2 class="mt-2 text-3xl font-bold tracking-tight text-gray-900">
                        Our services
                    </h2>

                    <p class="mt-2 text-gray-500">
                        Everything you need, right at your doorstep.
                    </p>
                </div>

                <a
                    href="#"
                    class="hidden text-sm font-semibold text-gray-900 hover:underline sm:block"
                >
                    View all →
                </a>

            </div>

            
            <div class="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>

                    <button
                        type="button"
                        @click="openSubcategories(<?php echo e($category['id']); ?>, <?php echo \Illuminate\Support\Js::from($category['name'])->toHtml() ?>, <?php echo \Illuminate\Support\Js::from($category['image'])->toHtml() ?>)"
                        class="group w-full text-left"
                    >

                        <div class="overflow-hidden rounded-2xl border border-gray-200 bg-white transition hover:-translate-y-1 hover:border-indigo-200 hover:shadow-md">

                            <div class="aspect-square overflow-hidden bg-gray-100">

                                <img
                                    src="<?php echo e($category['image']); ?>"
                                    alt="<?php echo e($category['name']); ?>"
                                    class="h-full w-full object-cover transition duration-500 group-hover:scale-105"
                                >

                            </div>

                            <div class="p-4">

                                <div class="flex items-center justify-between gap-2">

                                    <h3 class="text-sm font-semibold text-gray-900">
                                        <?php echo e($category['name']); ?>

                                    </h3>

                                    <svg
                                        class="h-4 w-4 shrink-0 text-gray-400 transition group-hover:translate-x-1 group-hover:text-indigo-600"
                                        fill="none"
                                        stroke="currentColor"
                                        viewBox="0 0 24 24"
                                    >
                                        <path
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                            stroke-width="2"
                                            d="m9 5 7 7-7 7"
                                        />
                                    </svg>

                                </div>

                            </div>

                        </div>

                    </button>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

            </div>

        </div>

    </section>

    
    <section class="bg-white py-16">

        <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">

            
            <div class="flex items-end justify-between">

                <div>
                    <p class="text-sm font-semibold uppercase tracking-wider text-gray-400">
                        Top picks
                    </p>

                    <h2 class="mt-2 text-3xl font-bold tracking-tight text-gray-900">
                        Popular services
                    </h2>

                    <p class="mt-2 text-gray-500">
                        Book highly rated professionals near you.
                    </p>
                </div>

                <a
                    href="#"
                    class="hidden rounded-lg border border-gray-200 px-4 py-2 text-sm font-semibold text-gray-700 transition hover:bg-gray-50 sm:block"
                >
                    View all services
                </a>

            </div>


            
            


            
            <div class="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $popularPackages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <div class="overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm">
                        
                        <div class="aspect-[4/3] overflow-hidden bg-gray-100">
                            <img
                                src="<?php echo e($package['image']); ?>"
                                alt="<?php echo e($package['name']); ?>"
                                class="h-full w-full object-cover"
                            >
                        </div>

                        <div class="p-5">
                            <h3 class="font-semibold text-gray-900">
                                <?php echo e($package['name']); ?>

                            </h3>

                            <div class="mt-3 flex items-center justify-between">
                                <span class="text-lg font-bold text-gray-900">
                                    ₹<?php echo e(number_format((float) $package['starting_price'])); ?>

                                </span>

                                <span class="text-sm text-gray-500">
                                    ★ <?php echo e($package['rating']); ?>

                                </span>
                            </div>

                            <a
                                href="<?php echo e(route('services.show', ['service' => $package['id']])); ?>"
                                class="mt-4 block rounded-xl bg-indigo-600 px-4 py-3 text-center text-sm font-semibold text-white hover:bg-indigo-700"
                            >
                                View Service
                            </a>
                        </div>

                    </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

            </div>


            
            <div class="mt-8 text-center sm:hidden">

                <a
                    href="#"
                    class="inline-flex rounded-lg border border-gray-200 px-5 py-3 text-sm font-semibold text-gray-700"
                >
                    View all services
                </a>

            </div>

        </div>

    </section>

    
    <section id="how-it-works" class="bg-gray-50 py-16 sm:py-20">

        <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">

            
            <div class="mx-auto max-w-2xl text-center">

                <p class="text-sm font-semibold uppercase tracking-wider text-gray-400">
                    Simple & easy
                </p>

                <h2 class="mt-2 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
                    How it works
                </h2>

                <p class="mt-4 text-gray-500">
                    Get professional services at your doorstep in just a few simple steps.
                </p>

            </div>


            
            <div class="relative mt-12 grid gap-10 md:grid-cols-3">

                
                <div class="absolute left-1/2 top-12 hidden h-px w-2/3 -translate-x-1/2 bg-gray-200 md:block"></div>


                
                <div class="relative text-center">

                    <div class="relative mx-auto flex h-24 w-24 items-center justify-center rounded-full border-8 border-gray-50 bg-white shadow-sm">

                        <div class="flex h-14 w-14 items-center justify-center rounded-2xl bg-gray-900 text-white">

                            <svg
                                class="h-7 w-7"
                                fill="none"
                                stroke="currentColor"
                                viewBox="0 0 24 24"
                            >
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    stroke-width="1.8"
                                    d="M21 21l-4.35-4.35m2.35-5.65a8 8 0 11-16 0 8 8 0 0116 0z"
                                />
                            </svg>

                        </div>

                    </div>

                    <span class="mt-6 inline-block rounded-full bg-white px-3 py-1 text-xs font-semibold text-gray-500 shadow-sm">
                        STEP 01
                    </span>

                    <h3 class="mt-3 text-lg font-bold text-gray-900">
                        Choose a service
                    </h3>

                    <p class="mx-auto mt-2 max-w-xs text-sm leading-6 text-gray-500">
                        Browse our services and choose the one that suits your needs.
                    </p>

                </div>


                
                <div class="relative text-center">

                    <div class="relative mx-auto flex h-24 w-24 items-center justify-center rounded-full border-8 border-gray-50 bg-white shadow-sm">

                        <div class="flex h-14 w-14 items-center justify-center rounded-2xl bg-gray-900 text-white">

                            <svg
                                class="h-7 w-7"
                                fill="none"
                                stroke="currentColor"
                                viewBox="0 0 24 24"
                            >
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    stroke-width="1.8"
                                    d="M8 7V3m8 4V3M4 11h16M5 5h14a1 1 0 011 1v14a1 1 0 01-1 1H5a1 1 0 01-1-1V6a1 1 0 011-1z"
                                />
                            </svg>

                        </div>

                    </div>

                    <span class="mt-6 inline-block rounded-full bg-white px-3 py-1 text-xs font-semibold text-gray-500 shadow-sm">
                        STEP 02
                    </span>

                    <h3 class="mt-3 text-lg font-bold text-gray-900">
                        Pick date & time
                    </h3>

                    <p class="mx-auto mt-2 max-w-xs text-sm leading-6 text-gray-500">
                        Select a convenient date and time that works best for you.
                    </p>

                </div>


                
                <div class="relative text-center">

                    <div class="relative mx-auto flex h-24 w-24 items-center justify-center rounded-full border-8 border-gray-50 bg-white shadow-sm">

                        <div class="flex h-14 w-14 items-center justify-center rounded-2xl bg-gray-900 text-white">

                            <svg
                                class="h-7 w-7"
                                fill="none"
                                stroke="currentColor"
                                viewBox="0 0 24 24"
                            >
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    stroke-width="1.8"
                                    d="M5 13l4 4L19 7"
                                />
                            </svg>

                        </div>

                    </div>

                    <span class="mt-6 inline-block rounded-full bg-white px-3 py-1 text-xs font-semibold text-gray-500 shadow-sm">
                        STEP 03
                    </span>

                    <h3 class="mt-3 text-lg font-bold text-gray-900">
                        Relax & enjoy
                    </h3>

                    <p class="mx-auto mt-2 max-w-xs text-sm leading-6 text-gray-500">
                        Our verified professional arrives at your doorstep and gets the job done.
                    </p>

                </div>

            </div>

        </div>

    </section>


    
    <section class="bg-white py-16 sm:py-20">

        <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">

            <div class="grid items-center gap-12 lg:grid-cols-2">

                
                <div>

                    <p class="text-sm font-semibold uppercase tracking-wider text-gray-400">
                        Why ServiceHub
                    </p>

                    <h2 class="mt-3 max-w-xl text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
                        Quality service you can trust.
                    </h2>

                    <p class="mt-5 max-w-xl text-base leading-7 text-gray-500">
                        We make it simple to find reliable professionals for
                        your everyday home service needs.
                    </p>


                    
                    <div class="mt-8 space-y-6">

                        
                        <div class="flex gap-4">

                            <div class="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gray-100">

                                <svg
                                    class="h-6 w-6 text-gray-800"
                                    fill="none"
                                    stroke="currentColor"
                                    viewBox="0 0 24 24"
                                >
                                    <path
                                        stroke-linecap="round"
                                        stroke-linejoin="round"
                                        stroke-width="1.8"
                                        d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                                    />
                                </svg>

                            </div>

                            <div>
                                <h3 class="font-bold text-gray-900">
                                    Verified professionals
                                </h3>

                                <p class="mt-1 text-sm leading-6 text-gray-500">
                                    Connect with trusted professionals for your service requirements.
                                </p>
                            </div>

                        </div>


                        
                        <div class="flex gap-4">

                            <div class="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gray-100">

                                <svg
                                    class="h-6 w-6 text-gray-800"
                                    fill="none"
                                    stroke="currentColor"
                                    viewBox="0 0 24 24"
                                >
                                    <path
                                        stroke-linecap="round"
                                        stroke-linejoin="round"
                                        stroke-width="1.8"
                                        d="M12 8v4l3 2m6-2a9 9 0 11-18 0 9 9 0 0118 0z"
                                    />
                                </svg>

                            </div>

                            <div>
                                <h3 class="font-bold text-gray-900">
                                    On-time service
                                </h3>

                                <p class="mt-1 text-sm leading-6 text-gray-500">
                                    Choose a convenient time and get your service when you need it.
                                </p>
                            </div>

                        </div>


                        
                        <div class="flex gap-4">

                            <div class="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gray-100">

                                <svg
                                    class="h-6 w-6 text-gray-800"
                                    fill="none"
                                    stroke="currentColor"
                                    viewBox="0 0 24 24"
                                >
                                    <path
                                        stroke-linecap="round"
                                        stroke-linejoin="round"
                                        stroke-width="1.8"
                                        d="M12 15.5a3.5 3.5 0 100-7 3.5 3.5 0 000 7z"
                                    />

                                    <path
                                        stroke-linecap="round"
                                        stroke-linejoin="round"
                                        stroke-width="1.8"
                                        d="M19.4 15a1.7 1.7 0 00.34 1.88l.06.06-1.5 1.5-.06-.06a1.7 1.7 0 00-1.88-.34 1.7 1.7 0 00-1.03 1.56V20h-2.12v-.08a1.7 1.7 0 00-1.03-1.56 1.7 1.7 0 00-1.88.34l-.06.06-1.5-1.5.06-.06A1.7 1.7 0 008.4 15a1.7 1.7 0 00-1.56-1.03H6.76v-2.12h.08A1.7 1.7 0 008.4 10.8a1.7 1.7 0 00-.34-1.88L8 8.86l1.5-1.5.06.06a1.7 1.7 0 001.88.34 1.7 1.7 0 001.03-1.56V6h2.12v.08a1.7 1.7 0 001.03 1.56 1.7 1.7 0 001.88-.34l.06-.06 1.5 1.5-.06.06A1.7 1.7 0 0019.4 10.8a1.7 1.7 0 001.56 1.03H21v2.12h-.04A1.7 1.7 0 0019.4 15z"
                                    />
                                </svg>

                            </div>

                            <div>
                                <h3 class="font-bold text-gray-900">
                                    Quality guaranteed
                                </h3>

                                <p class="mt-1 text-sm leading-6 text-gray-500">
                                    We focus on providing a smooth and reliable service experience.
                                </p>
                            </div>

                        </div>

                    </div>

                </div>


                
                <div class="relative">

                    <div class="rounded-3xl bg-gray-100 p-8 sm:p-10">

                        <div class="grid grid-cols-2 gap-4">

                            <div class="rounded-2xl bg-white p-6">

                                <p class="text-3xl font-bold text-gray-900">
                                    10K+
                                </p>

                                <p class="mt-2 text-sm text-gray-500">
                                    Customers served
                                </p>

                            </div>


                            <div class="rounded-2xl bg-white p-6">

                                <p class="text-3xl font-bold text-gray-900">
                                    500+
                                </p>

                                <p class="mt-2 text-sm text-gray-500">
                                    Service professionals
                                </p>

                            </div>


                            <div class="rounded-2xl bg-white p-6">

                                <p class="text-3xl font-bold text-gray-900">
                                    50+
                                </p>

                                <p class="mt-2 text-sm text-gray-500">
                                    Services available
                                </p>

                            </div>


                            <div class="rounded-2xl bg-gray-900 p-6 text-white">

                                <p class="text-3xl font-bold">
                                    4.8 ★
                                </p>

                                <p class="mt-2 text-sm text-gray-300">
                                    Average customer rating
                                </p>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </section>
    <div
        x-show="open"
        x-cloak
        @keydown.escape.window="close()"
        class="fixed inset-0 z-50"
    >
        <!-- Overlay -->
        <div
            x-show="open"
            x-transition.opacity
            @click="close()"
            class="absolute inset-0 bg-gray-900/50 backdrop-blur-sm"
        ></div>

        <!-- Modal -->
        <div class="relative flex min-h-full items-center justify-center p-4">

            <div
                x-show="open"
                x-transition
                @click.stop
                class="relative w-full max-w-lg overflow-hidden rounded-3xl bg-white shadow-2xl"
            >

                <!-- Header -->
                <div class="flex items-center justify-between border-b border-gray-200 px-5 py-4">

                    <div class="flex items-center gap-3">

                        <div class="h-11 w-11 overflow-hidden rounded-xl bg-gray-100">

                            <img
                                x-show="categoryImage"
                                :src="categoryImage"
                                :alt="categoryName"
                                class="h-full w-full object-cover"
                            >

                        </div>

                        <div>

                            <p class="text-xs font-medium uppercase tracking-wide text-indigo-600">
                                Services
                            </p>

                            <h2
                                class="text-lg font-bold text-gray-900"
                                x-text="categoryName"
                            ></h2>

                        </div>

                    </div>

                    <button
                        type="button"
                        @click="close()"
                        class="flex h-9 w-9 items-center justify-center rounded-xl text-gray-500 hover:bg-gray-100 hover:text-gray-900"
                    >
                        <svg
                            class="h-5 w-5"
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                        >
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                stroke-width="2"
                                d="M6 6l12 12M18 6 6 18"
                            />
                        </svg>
                    </button>

                </div>

                <!-- Content -->
                <div class="max-h-[65vh] overflow-y-auto p-5">

                    <!-- Loading -->
                    <div
                        x-show="loading"
                        class="py-10 text-center"
                    >

                        <div class="mx-auto h-8 w-8 animate-spin rounded-full border-2 border-gray-200 border-t-indigo-600"></div>

                        <p class="mt-3 text-sm text-gray-500">
                            Loading services...
                        </p>

                    </div>

                    <!-- Error -->
                    <div
                        x-show="!loading && error"
                        x-cloak
                        class="rounded-xl border border-red-200 bg-red-50 p-4 text-center"
                    >

                        <p
                            class="text-sm font-medium text-red-700"
                            x-text="error"
                        ></p>

                        <button
                            type="button"
                            @click="loadSubcategories()"
                            class="mt-3 text-sm font-semibold text-red-700 underline"
                        >
                            Try Again
                        </button>

                    </div>

                    <!-- Empty -->
                    <div
                        x-show="!loading && !error && groups.length === 0"
                        x-cloak
                        class="py-10 text-center"
                    >

                        <div class="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-gray-100">

                            <svg
                                class="h-6 w-6 text-gray-400"
                                fill="none"
                                stroke="currentColor"
                                viewBox="0 0 24 24"
                            >
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    stroke-width="2"
                                    d="M9 12h6m-3-3v6m9-3a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"
                                />
                            </svg>

                        </div>

                        <p class="mt-3 text-sm font-medium text-gray-700">
                            No services available
                        </p>

                        <p class="mt-1 text-xs text-gray-500">
                            Please check again later.
                        </p>

                    </div>

                    <!-- Groups -->
                    <div
                        x-show="!loading && !error && groups.length > 0"
                        x-cloak
                        class="space-y-6"
                    >

                        <template
                            x-for="group in groups"
                            :key="group.group_label"
                        >

                            <div>

                                <!-- Group title -->
                                <div class="mb-3 flex items-center gap-2">

                                    <div class="h-1.5 w-1.5 rounded-full bg-indigo-600"></div>

                                    <h3
                                        class="text-sm font-bold text-gray-900"
                                        x-text="group.group_label"
                                    ></h3>

                                </div>

                                <!-- Sub categories -->
                                <div class="space-y-2">

                                    <template
                                        x-for="subcategory in group.sub_categories"
                                        :key="subcategory.id"
                                    >

                                        <a
                                            :href="'#'"
                                            @click.prevent="selectSubcategory(subcategory)"
                                            class="group flex items-center justify-between rounded-xl border border-gray-200 bg-white px-4 py-3.5 transition hover:border-indigo-200 hover:bg-indigo-50/50"
                                        >

                                            <div class="flex min-w-0 items-center gap-3">

                                                <!-- Icon -->
                                                <div class="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-gray-100">

                                                    <template x-if="subcategory.icon">

                                                        <img
                                                            :src="subcategory.icon"
                                                            :alt="subcategory.name"
                                                            class="h-full w-full object-cover"
                                                        >

                                                    </template>

                                                    <template x-if="!subcategory.icon">

                                                        <svg
                                                            class="h-5 w-5 text-gray-400"
                                                            fill="none"
                                                            stroke="currentColor"
                                                            viewBox="0 0 24 24"
                                                        >
                                                            <path
                                                                stroke-linecap="round"
                                                                stroke-linejoin="round"
                                                                stroke-width="2"
                                                                d="M9 12h6m-3-3v6m9-3a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"
                                                            />
                                                        </svg>

                                                    </template>

                                                </div>

                                                <div class="min-w-0">

                                                    <h4
                                                        class="truncate text-sm font-semibold text-gray-800 group-hover:text-indigo-600"
                                                        x-text="subcategory.name"
                                                    ></h4>

                                                    <p
                                                        class="mt-1 text-xs text-gray-400"
                                                        x-text="subcategory.total_bookings_label || 'Explore available services'"
                                                    ></p>

                                                </div>

                                            </div>

                                            <div class="ml-3 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-gray-50 text-gray-400 transition group-hover:bg-indigo-100 group-hover:text-indigo-600">

                                                <svg
                                                    class="h-4 w-4"
                                                    fill="none"
                                                    stroke="currentColor"
                                                    viewBox="0 0 24 24"
                                                >
                                                    <path
                                                        stroke-linecap="round"
                                                        stroke-linejoin="round"
                                                        stroke-width="2"
                                                        d="m9 5 7 7-7 7"
                                                    />
                                                </svg>

                                            </div>

                                        </a>

                                    </template>

                                </div>

                            </div>

                        </template>

                    </div>

                </div>

                <!-- Footer -->
                <div class="border-t border-gray-200 bg-gray-50 px-5 py-4">

                    <button
                        type="button"
                        @click="close()"
                        class="w-full rounded-xl border border-gray-200 bg-white px-4 py-3 text-sm font-semibold text-gray-700 hover:bg-gray-50"
                    >
                        Close
                    </button>

                </div>

            </div>

        </div>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
<script>
    function serviceCategoryModal() {
        return {
            open: false,

            loading: false,

            error: null,

            categoryId: null,

            categoryName: '',

            categoryImage: '',

            groups: [],

            openSubcategories(id, name, image) {
                this.categoryId = id;
                this.categoryName = name;
                this.categoryImage = image;

                this.groups = [];
                this.error = null;
                this.loading = true;
                this.open = true;

                this.loadSubcategories();
            },

            async loadSubcategories() {
                this.loading = true;
                this.error = null;

                try {

                    const response = await fetch(
                        `/categories/${this.categoryId}/sub-categories`,
                        {
                            method: 'GET',

                            headers: {
                                'Accept': 'application/json',
                                'X-Requested-With': 'XMLHttpRequest',
                            },

                            credentials: 'same-origin',
                        }
                    );

                    const result = await response.json();

                    if (!response.ok || !result.status) {
                        throw new Error(
                            result.message || 'Unable to load services.'
                        );
                    }

                    this.groups = result.data?.groups || [];

                } catch (error) {

                    console.error(
                        'Sub-category API error:',
                        error
                    );

                    this.error =
                        error.message ||
                        'Unable to load services.';

                } finally {

                    this.loading = false;

                }
            },

            selectSubcategory(subcategory) {
                window.location.href = `/sub-categories/${subcategory.id}/services`;

                /*
                 * Next step:
                 *
                 * Collection API
                 * OR
                 * Package Group API
                 *
                 * depending on your backend hierarchy.
                 */

                // Example:
                // window.location.href =
                //     `/sub-categories/${subcategory.id}`;
            },

            close() {
                this.open = false;

                this.categoryId = null;
                this.categoryName = '';
                this.categoryImage = '';

                this.groups = [];
                this.error = null;
                this.loading = false;
            }
        }
    }
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\homo\resources\views/home/index.blade.php ENDPATH**/ ?>