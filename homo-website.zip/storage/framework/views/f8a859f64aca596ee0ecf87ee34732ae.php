<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo $__env->yieldContent('title', 'Home Services'); ?></title>

    <script src="https://cdn.tailwindcss.com"></script>

   
    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body class="bg-gray-50 text-gray-900 antialiased">

    <?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make('components.login-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>
    <script type="text/javascript">
        window.openLocationModal = function () {
            const modal = document.getElementById('location-picker');

            if (!modal) {
                console.error('Location modal not found.');
                return;
            }

            modal.classList.remove('hidden');
            document.body.classList.add('overflow-hidden');

            const input = document.getElementById('locationSearch');

            if (input) {
                setTimeout(() => input.focus(), 100);
            }
        };

        window.closeLocationModal = function () {
            const modal = document.getElementById('location-picker');

            if (!modal) {
                return;
            }

            modal.classList.add('hidden');
            document.body.classList.remove('overflow-hidden');
        };
    </script>
</body>
</html><?php /**PATH C:\wamp64\www\homo\resources\views/layouts/app.blade.php ENDPATH**/ ?>