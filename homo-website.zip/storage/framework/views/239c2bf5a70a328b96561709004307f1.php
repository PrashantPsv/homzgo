<?php $__env->startSection('title', 'Choose a Service | ServiceHub'); ?>

<?php $__env->startSection('content'); ?>

<div
    x-data="subcategoryServices({
        subCategoryId: <?php echo e($subCategoryId); ?>,
        collections: <?php echo \Illuminate\Support\Js::from($collections)->toHtml() ?>,
    })"
    x-init="init()"
    class="min-h-screen bg-gray-50"
>

    
    <div class="border-b border-gray-200 bg-white">

        <div class="mx-auto max-w-7xl px-4 py-5 sm:px-6 lg:px-8">

            <div class="flex items-center gap-3">

                <button
                    type="button"
                    onclick="history.back()"
                    class="flex h-10 w-10 items-center justify-center rounded-xl border border-gray-200 text-gray-500 transition hover:bg-gray-50"
                >
                    <svg
                        class="h-5 w-5"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                    >
                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="2"
                            d="M15 19l-7-7 7-7"
                        />
                    </svg>
                </button>

                <div>

                    <p class="text-xs font-medium uppercase tracking-wide text-indigo-600">
                        Choose a service
                    </p>

                    <h1 class="text-xl font-bold text-gray-900">
                        Services
                    </h1>

                </div>

            </div>

        </div>

    </div>


    
    <main class="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">

        <div class="grid gap-8 lg:grid-cols-[230px_minmax(0,1fr)]">


            
            <aside>

                <div class="lg:sticky lg:top-6">

                    <h2 class="mb-3 text-sm font-bold text-gray-900">
                        Service Type
                    </h2>

                    
                    <div class="flex gap-2 overflow-x-auto pb-2 lg:hidden">

                        <template
                            x-for="collection in collections"
                            :key="collection.id"
                        >

                            <button
                                type="button"
                                @click="selectCollection(collection)"
                                class="shrink-0 rounded-full border px-4 py-2 text-sm font-semibold"
                                :class="
                                    selectedCollection?.id === collection.id
                                    ? 'border-indigo-600 bg-indigo-600 text-white'
                                    : 'border-gray-200 bg-white text-gray-700'
                                "
                                x-text="collection.name"
                            ></button>

                        </template>

                    </div>


                    
                    <div class="hidden space-y-2 lg:block">

                        <template
                            x-for="collection in collections"
                            :key="collection.id"
                        >

                            <button
                                type="button"
                                @click="selectCollection(collection)"
                                class="flex w-full items-center justify-between rounded-xl px-4 py-3 text-left transition"
                                :class="
                                    selectedCollection?.id === collection.id
                                    ? 'bg-indigo-50 text-indigo-700'
                                    : 'bg-white text-gray-700 hover:bg-gray-100'
                                "
                            >

                                <span
                                    class="text-sm font-semibold"
                                    x-text="collection.name"
                                ></span>

                                <svg
                                    class="h-4 w-4"
                                    fill="none"
                                    stroke="currentColor"
                                    viewBox="0 0 24 24"
                                >
                                    <path
                                        stroke-linecap="round"
                                        stroke-linejoin="round"
                                        stroke-width="2"
                                        d="m9 5 7 7-7 7"
                                    />
                                </svg>

                            </button>

                        </template>

                    </div>

                </div>

            </aside>


            
            <section>


                
                <div
                    x-show="loading"
                    x-cloak
                    class="rounded-2xl border border-gray-200 bg-white p-12 text-center"
                >

                    <div class="mx-auto h-8 w-8 animate-spin rounded-full border-2 border-gray-200 border-t-indigo-600"></div>

                    <p class="mt-3 text-sm text-gray-500">
                        Loading services...
                    </p>

                </div>


                
                <div
                    x-show="error"
                    x-cloak
                    class="rounded-2xl border border-red-200 bg-red-50 p-5"
                >

                    <p
                        class="text-sm font-medium text-red-700"
                        x-text="error"
                    ></p>

                    <button
                        type="button"
                        @click="loadPackageGroups()"
                        class="mt-3 text-sm font-semibold text-red-700 underline"
                    >
                        Try Again
                    </button>

                </div>


                
                <div
                    x-show="!loading && !error"
                    x-cloak
                >

                    <div class="mb-6">

                        <h2
                            class="text-2xl font-bold text-gray-900"
                            x-text="selectedCollection?.name || 'Available Services'"
                        ></h2>

                        <p class="mt-1 text-sm text-gray-500">
                            Select the service you need
                        </p>

                    </div>


                    
                    <div class="space-y-8">

                        <template
                            x-for="group in packageGroups"
                            :key="group.id"
                        >

                            <div>

                                <div class="mb-4">

                                    <h3
                                        class="text-lg font-bold text-gray-900"
                                        x-text="group.name"
                                    ></h3>

                                    <p
                                        x-show="group.description"
                                        class="mt-1 text-sm text-gray-500"
                                        x-text="group.description"
                                    ></p>

                                </div>


                                <div class="space-y-3">

                                    <template
                                        x-for="pkg in group.packages"
                                        :key="pkg.id"
                                    >

                                        <div
                                            class="rounded-2xl border border-gray-200 bg-white p-4 shadow-sm transition hover:border-indigo-200 hover:shadow-md"
                                        >

                                            <div class="flex gap-4">


                                                
                                                <div class="hidden h-28 w-28 shrink-0 overflow-hidden rounded-xl bg-gray-100 sm:block">

                                                    <template x-if="pkg.thumbnail_image">

                                                        <img
                                                            :src="pkg.thumbnail_image"
                                                            :alt="pkg.name"
                                                            class="h-full w-full object-cover"
                                                        >

                                                    </template>

                                                    <template x-if="!pkg.thumbnail_image">

                                                        <div class="flex h-full w-full items-center justify-center">

                                                            <svg
                                                                class="h-9 w-9 text-gray-300"
                                                                fill="none"
                                                                stroke="currentColor"
                                                                viewBox="0 0 24 24"
                                                            >
                                                                <path
                                                                    stroke-linecap="round"
                                                                    stroke-linejoin="round"
                                                                    stroke-width="1.5"
                                                                    d="M19.5 8.25l-7.5-5.25-7.5 5.25m15 0v7.5l-7.5 5.25m7.5-12.75l-7.5 5.25m0 0L4.5 8.25m7.5 5.25v7.5"
                                                                />
                                                            </svg>

                                                        </div>

                                                    </template>

                                                </div>


                                                
                                                <div class="min-w-0 flex-1">

                                                    <h4 class="text-base font-semibold text-gray-900">
                                                        <span x-text="pkg.name"></span>
                                                    </h4>


                                                    
                                                    <div
                                                        x-show="Number(pkg.rating) > 0"
                                                        class="mt-2 flex items-center gap-2"
                                                    >

                                                        <span class="text-sm font-semibold text-gray-700">
                                                            ⭐
                                                            <span x-text="pkg.rating"></span>
                                                        </span>

                                                        <span class="text-xs text-gray-400">
                                                            (<span x-text="pkg.review_count"></span>)
                                                        </span>

                                                    </div>


                                                    
                                                    <div class="mt-3 flex items-center gap-2">

                                                        <span class="text-lg font-bold text-gray-900">

                                                            ₹<span
                                                                x-text="Number(pkg.base_price).toLocaleString('en-IN')"
                                                            ></span>

                                                        </span>


                                                        <template x-if="pkg.strike_price">

                                                            <span class="text-sm text-gray-400 line-through">

                                                                ₹<span
                                                                    x-text="Number(pkg.strike_price).toLocaleString('en-IN')"
                                                                ></span>

                                                            </span>

                                                        </template>

                                                    </div>

                                                </div>


                                                
                                                <div class="flex shrink-0 items-center">

                                                    <button
                                                        type="button"
                                                        @click="openPackageDetails(pkg)"
                                                        class="rounded-xl border border-indigo-600 bg-white px-5 py-2 text-sm font-bold text-indigo-600 transition hover:bg-indigo-600 hover:text-white"
                                                    >
                                                        Add
                                                    </button>

                                                </div>

                                            </div>

                                        </div>

                                    </template>

                                </div>

                            </div>

                        </template>

                    </div>


                    
                    <div
                        x-show="packageGroups.length === 0"
                        class="rounded-2xl border border-gray-200 bg-white p-12 text-center"
                    >

                        <p class="text-sm font-medium text-gray-700">
                            No services available.
                        </p>

                    </div>

                </div>

            </section>

        </div>

    </main>

    <div
    x-show="packageModal"
    x-cloak
    class="fixed inset-0 z-[9999] flex items-center justify-center p-4"
    @keydown.escape.window="closePackageModal()"
>
    <!-- Background -->
    <div
        class="absolute inset-0 bg-black/60"
        @click="closePackageModal()"
    ></div>

    <!-- Modal -->
    <div
        class="relative z-10 w-full max-w-2xl overflow-hidden rounded-3xl bg-white shadow-2xl"
        @click.stop
    >

        <!-- Header -->
        <div class="flex items-center justify-between border-b p-5">

            <div>
                <p class="text-xs font-semibold uppercase text-indigo-600">
                    Service Details
                </p>

                <h2
                    class="mt-1 text-xl font-bold text-gray-900"
                    x-text="selectedPackage?.name || 'Service'"
                ></h2>
            </div>

            <button
                type="button"
                @click="closePackageModal()"
                class="flex h-9 w-9 items-center justify-center rounded-full bg-gray-100"
            >
                ✕
            </button>

        </div>

        <!-- Loading -->
        <div
            x-show="packageLoading"
            class="flex min-h-[300px] items-center justify-center p-8"
        >
            <div class="text-center">

                <div class="mx-auto h-10 w-10 animate-spin rounded-full border-4 border-gray-200 border-t-indigo-600"></div>

                <p class="mt-4 text-sm text-gray-500">
                    Loading service details...
                </p>

            </div>
        </div>

        <!-- Details -->
        <div
            x-show="!packageLoading && selectedPackage"
            class="max-h-[70vh] overflow-y-auto p-6"
        >

            <p
                class="text-sm leading-6 text-gray-600"
                x-text="selectedPackage?.description || 'Professional service by our trained experts.'"
            ></p>

            <!-- Price -->
            <div class="mt-5 rounded-2xl bg-gray-50 p-4">

                <p class="text-sm text-gray-500">
                    Starting price
                </p>

                <p class="mt-1 text-2xl font-bold text-gray-900">
                    ₹<span x-text="selectedPackage?.base_price"></span>
                </p>

            </div>

            <!-- Highlights -->
            <template
                x-if="selectedPackage?.highlights?.length"
            >
                <div class="mt-6">

                    <h3 class="font-bold text-gray-900">
                        Highlights
                    </h3>

                    <div class="mt-3 space-y-2">

                        <template
                            x-for="highlight in selectedPackage.highlights"
                            :key="highlight.id"
                        >
                            <div class="flex gap-2 text-sm text-gray-600">

                                <span class="text-green-600">
                                    ✓
                                </span>

                                <span
                                    x-text="highlight.text"
                                ></span>

                            </div>
                        </template>

                    </div>

                </div>
            </template>

            <!-- Included / Excluded -->
            <template
                x-if="selectedPackage?.includes?.length"
            >
                <div class="mt-6">

                    <!-- What's Included -->
                    <template
                        x-if="selectedPackage.includes.some(item => item.type === 'included')"
                    >
                        <div>
                            <h3 class="font-bold text-gray-900">
                                What's Included
                            </h3>

                            <div class="mt-3 space-y-2">

                                <template
                                    x-for="item in selectedPackage.includes.filter(item => item.type === 'included')"
                                    :key="item.id"
                                >
                                    <div class="flex items-start gap-2 text-sm">

                                        <span class="mt-0.5 text-green-600">
                                            ✓
                                        </span>

                                        <span
                                            class="text-gray-600"
                                            x-text="item.text"
                                        ></span>

                                    </div>
                                </template>

                            </div>
                        </div>
                    </template>


                    <!-- What's Excluded -->
                    <template
                        x-if="selectedPackage.includes.some(item => item.type === 'excluded')"
                    >
                        <div class="mt-6">

                            <h3 class="font-bold text-gray-900">
                                What's Excluded
                            </h3>

                            <div class="mt-3 space-y-2">

                                <template
                                    x-for="item in selectedPackage.includes.filter(item => item.type === 'excluded')"
                                    :key="item.id"
                                >
                                    <div class="flex items-start gap-2 text-sm">

                                        <span class="mt-0.5 text-red-500">
                                            ×
                                        </span>

                                        <span
                                            class="text-gray-600"
                                            x-text="item.text"
                                        ></span>

                                    </div>
                                </template>

                            </div>
                        </div>
                    </template>

                </div>
            </template>

            <!-- Process -->
            <template
                x-if="selectedPackage?.process_steps?.length"
            >
                <div class="mt-6">

                    <h3 class="font-bold text-gray-900">
                        How it works
                    </h3>

                    <div class="mt-4 space-y-4">

                        <template
                            x-for="(step, index) in selectedPackage.process_steps"
                            :key="step.id"
                        >

                            <div class="flex gap-3">

                                <div class="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-indigo-50 text-sm font-bold text-indigo-600">
                                    <span x-text="index + 1"></span>
                                </div>

                                <div>
                                    <p
                                        class="font-semibold text-gray-900"
                                        x-text="step.title"
                                    ></p>

                                    <p
                                        class="mt-1 text-sm text-gray-500"
                                        x-text="step.description"
                                    ></p>
                                </div>

                            </div>

                        </template>

                    </div>

                </div>
            </template>

        </div>

        <!-- Popup Footer -->
        <div
            x-show="!packageLoading && selectedPackage"
            class="border-t bg-white"
        >
            
            <div
                x-show="packageError"
                x-transition
                class="border-b border-red-100 bg-red-50 px-5 py-3"
            >
                <div class="flex items-center gap-2 text-sm text-red-600">
                    <svg
                        class="h-4 w-4 shrink-0"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                    >
                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="2"
                            d="M12 9v3m0 4h.01M10.29 3.86l-8.82 14a2 2 0 001.71 3h17.64a2 2 0 001.71-3l-8.82-14a2 2 0 00-3.42 0z"
                        />
                    </svg>

                    <span x-text="packageError"></span>
                </div>
            </div>

            
            <div class="flex items-center justify-between p-5">

                <div>
                    <p class="text-xs text-gray-500">
                        Total
                    </p>

                    <p class="text-xl font-bold text-gray-900">
                        ₹<span
                            x-text="selectedPackage?.base_price"
                        ></span>
                    </p>
                </div>

                
                <template x-if="Number(selectedPackage?.iscart) !== 1">
                    <button
                        type="button"
                        @click="confirmAddPackage()"
                        :disabled="packageLoading"
                        class="rounded-xl bg-indigo-600 px-6 py-3 font-semibold text-white transition hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                        <span x-show="!packageLoading">
                            Add to Cart
                        </span>

                        <span x-show="packageLoading">
                            Adding...
                        </span>
                    </button>
                </template>

                
                <template x-if="Number(selectedPackage?.iscart) === 1">
                    <div class="flex items-center gap-3">

                        
                        <div class="flex items-center overflow-hidden rounded-xl border border-indigo-200">

                            <button
                                type="button"
                                @click="decreaseQuantity(selectedPackage)"
                                :disabled="packageLoading"
                                class="flex h-12 w-12 items-center justify-center bg-indigo-50 text-xl font-bold text-indigo-600 hover:bg-indigo-100 disabled:opacity-50"
                            >
                                −
                            </button>

                            <span
                                class="flex h-12 min-w-[50px] items-center justify-center bg-white text-base font-bold text-gray-900"
                                x-text="
                                    cart.find(
                                        item => Number(item.id) === Number(selectedPackage?.id)
                                    )?.quantity || 1
                                "
                            ></span>

                            <button
                                type="button"
                                @click="increaseQuantity(selectedPackage)"
                                :disabled="packageLoading"
                                class="flex h-12 w-12 items-center justify-center bg-indigo-50 text-xl font-bold text-indigo-600 hover:bg-indigo-100 disabled:opacity-50"
                            >
                                +
                            </button>

                        </div>

                        
                        <a
                            href="<?php echo e(route('cart.index')); ?>"
                            class="rounded-xl bg-indigo-600 px-5 py-3 text-sm font-semibold text-white transition hover:bg-indigo-700"
                        >
                            Proceed to Cart
                        </a>

                    </div>
                </template>

            </div>
        </div>

    </div>
</div>

</div>

<?php $__env->startPush('scripts'); ?>

<script>

function subcategoryServices(config) {
    return {
        subCategoryId: config.subCategoryId,
        collections: config.collections || [],

        selectedCollection: null,
        packageGroups: [],
        loading: false,
        error: null,

        cart: [],

        // Package details modal
        packageModal: false,
        packageLoading: false,
        packageError: null,
        selectedPackage: null,
        guestToken: null,

        init() {
            this.guestToken =
                localStorage.getItem('servicehub_guest_token');

            if (!this.guestToken) {
                this.guestToken = crypto.randomUUID();

                localStorage.setItem(
                    'servicehub_guest_token',
                    this.guestToken
                );
            }

            if (this.collections.length) {
                this.selectCollection(this.collections[0]);
            }
        },

        async selectCollection(collection) {
            this.selectedCollection = collection;
            this.packageGroups = [];
            this.loading = true;
            this.error = null;

            try {
                const response = await fetch(
                    `/service-collections/${collection.id}/package-groups`,
                    {
                        headers: {
                            'Accept': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest',
                        },
                        credentials: 'same-origin',
                    }
                );

                const result = await response.json();

                if (!response.ok || !result.status) {
                    throw new Error(
                        result.message || 'Unable to load services.'
                    );
                }

                this.packageGroups = result.data || [];

            } catch (error) {
                console.error('Package group error:', error);

                this.error =
                    error.message || 'Unable to load services.';

            } finally {
                this.loading = false;
            }
        },

        async openPackageDetails(pkg) {

            console.log('OPEN PACKAGE:', pkg);

            if (!pkg || !pkg.id) {
                console.error('Invalid package:', pkg);
                return;
            }

            // Open modal IMMEDIATELY
            this.packageModal = true;

            this.packageLoading = true;
            this.packageError = null;
            this.selectedPackage = null;

            try {
                const response = await fetch(
                    `/packages/${pkg.id}/details`,
                    {
                        method: 'GET',
                        headers: {
                            'Accept': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest',
                        },
                        credentials: 'same-origin',
                    }
                );

                const result = await response.json();

                console.log('PACKAGE DETAILS:', result);

                if (!response.ok || !result.status) {
                    throw new Error(
                        result.message ||
                        'Unable to load package details.'
                    );
                }

                this.selectedPackage = result.data;

                if (Number(pkg.iscart) === 1) {

                    const existing = this.cart.find(
                        item => item.id === pkg.id
                    );

                    if (!existing) {
                        this.cart.push({
                            id: pkg.id,
                            name: pkg.name,
                            price: Number(pkg.base_price),
                            quantity: 1,
                            pricing_mode: pkg.pricing_mode,
                            thumbnail_image: pkg.thumbnail_image || null,
                        });
                    }
                }

            } catch (error) {

                console.error(
                    'Package details error:',
                    error
                );

                this.packageError =
                    error.message ||
                    'Unable to load package details.';

            } finally {

                this.packageLoading = false;
            }
        },

        async increaseQuantity(pkg) {
            console.log('Increase package:', pkg);
            console.log('Current cart:', this.cart);

            const item = this.cart.find(
                item => Number(item.id) === Number(pkg.id)
            );

            console.log('Found cart item:', item);

            if (!item) {
                console.error('Cart item not found for package:', pkg.id);
                return;
            }

            await this.updateCartQuantity(
                Number(pkg.id),
                Number(item.quantity) + 1
            );
        },

        async decreaseQuantity(pkg) {
            console.log('Decrease package:', pkg);

            const item = this.cart.find(
                item => Number(item.id) === Number(pkg.id)
            );

            if (!item) {
                console.error('Cart item not found:', pkg.id);
                return;
            }

            if (Number(item.quantity) <= 1) {
                return;
            }

            await this.updateCartQuantity(
                Number(pkg.id),
                Number(item.quantity) - 1
            );
        },

        async updateCartQuantity(packageId, quantity) {
            console.log('updateCartQuantity');
            this.packageLoading = true;
            this.packageError = null;

            try {
                const currentItem = this.cart.find(item => Number(item.id) === Number(packageId) || Number(item.package_id) === Number(packageId));
                const cartItemId = currentItem?.cart_item_id || currentItem?.id;
                if (!cartItemId) throw new Error('Cart item not found. Please refresh the cart.');

                const response = await fetch(
                    `/cart/items/${cartItemId}`,
                    {
                        method: 'PUT',
                        headers: {
                            'Content-Type': 'application/json',
                            'Accept': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest',
                            'X-CSRF-TOKEN':
                                document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '',
                        },
                        credentials: 'same-origin',
                        body: JSON.stringify({
                            quantity: quantity,
                            guest_token: this.guestToken,
                        }),
                    }
                );

                const result = await response.json();

                console.log('CART UPDATE RESPONSE:', result);

                if (!response.ok || !result.status) {
                    throw new Error(
                        result.message || 'Unable to update cart.'
                    );
                }

                // Update local cart only after API succeeds
                const item = this.cart.find(item => item.id === packageId);

                if (item) {
                    item.quantity = quantity;
                }

                localStorage.setItem(
                    'servicehub_cart',
                    JSON.stringify(this.cart)
                );

            } catch (error) {
                console.error('Cart quantity update error:', error);

                this.packageError =
                    error.message || 'Unable to update cart quantity.';
            } finally {
                this.packageLoading = false;
            }
        },
        closePackageModal() {
            this.packageModal = false;
            this.selectedPackage = null;
            this.packageError = null;
        },

        async confirmAddPackage() {
            if (!this.selectedPackage) return;

            const packageId = this.selectedPackage.id;
            this.packageLoading = true;
            this.packageError = null;

            try {
                const response = await fetch(
                    '<?php echo e(route('cart.items.store')); ?>',
                    {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Accept': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest',
                            'X-CSRF-TOKEN':
                                document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '',
                        },
                        credentials: 'same-origin',
                        body: JSON.stringify({
                            package_id: packageId,
                            quantity: 1,
                            guest_token: this.guestToken,
                        }),
                    }
                );

                const result = await response.json();

                if (!response.ok || !result.status) {
                    throw new Error(
                        result.message || 'Unable to add service to cart.'
                    );
                }

                // Update local cart
                const existing = this.cart.find(item => Number(item.id) === Number(packageId) );

                if (existing) {
                    existing.quantity++;
                } else {
                    this.cart.push({
                        id: Number(packageId),
                        name: this.selectedPackage.name,
                        price: Number(this.selectedPackage.base_price),
                        quantity: 1,
                        pricing_mode: this.selectedPackage.pricing_mode,
                        thumbnail_image: this.selectedPackage.thumbnail_image || null,
                    });
                }

                // IMPORTANT:
                // Change iscart so popup immediately changes
                // from "Add to Cart" to +/- controls.
                this.selectedPackage.iscart = 1;

                // Save cart locally
                localStorage.setItem(
                    'servicehub_cart',
                    JSON.stringify(this.cart)
                );

                // DO NOT close popup
                // this.closePackageModal();

            } catch (error) {
                console.error('Add to cart error:', error);

                this.packageError =
                    error.message || 'Unable to add service to cart.';
            } finally {
                this.packageLoading = false;
            }
        },

        addPackage(pkg) {

            const existing = this.cart.find(
                item => item.id === pkg.id
            );

            if (existing) {
                existing.quantity++;
            } else {
                this.cart.push({
                    id: pkg.id,
                    name: pkg.name,
                    price: Number(pkg.base_price),
                    quantity: 1,
                    pricing_mode: pkg.pricing_mode,
                    thumbnail_image:
                        pkg.thumbnail_image || null,
                });
            }

            localStorage.setItem(
                'servicehub_cart',
                JSON.stringify(this.cart)
            );

            console.log('CART:', this.cart);
        },

        get cartCount() {
            return this.cart.reduce(
                (total, item) => total + item.quantity,
                0
            );
        },

        get cartTotal() {
            return this.cart.reduce(
                (total, item) =>
                    total +
                    (Number(item.price) * item.quantity),
                0
            );
        },
    }
}

</script>

<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\homo\resources\views/services/services.blade.php ENDPATH**/ ?>